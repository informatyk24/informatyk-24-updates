/* Informatyk-24 CMS 1.3.1 — stabilne menu mobilne, motyw i tabele */
(function () {
  'use strict';
  var mobile = function () { return window.matchMedia('(max-width: 850px)').matches; };
  [
    { id: 'adminShell', sidebar: '.admin-sidebar', toggle: '.admin-mobile-toggle' },
    { id: 'clientShell', sidebar: '.client-sidebar', toggle: '.client-toggle' }
  ].forEach(function (cfg) {
    var root = document.getElementById(cfg.id);
    if (!root) return;
    var side = root.querySelector(cfg.sidebar);
    var toggle = root.querySelector(cfg.toggle);
    if (!side || !toggle) return;
    if (!side.id) side.id = cfg.id + 'Sidebar';
    toggle.setAttribute('aria-controls', side.id);
    toggle.setAttribute('aria-expanded', 'false');
    toggle.setAttribute('aria-label', 'Otwórz menu');
    function close() {
      root.classList.remove('mobile-open');
      document.documentElement.classList.remove('i24-menu-open');
      document.body.classList.remove('i24-menu-open');
      toggle.setAttribute('aria-expanded', 'false');
      toggle.setAttribute('aria-label', 'Otwórz menu');
    }
    function open() {
      if (!mobile()) return;
      root.classList.add('mobile-open');
      document.documentElement.classList.add('i24-menu-open');
      document.body.classList.add('i24-menu-open');
      toggle.setAttribute('aria-expanded', 'true');
      toggle.setAttribute('aria-label', 'Zamknij menu');
    }
    toggle.addEventListener('click', function (e) {
      if (!mobile()) return;
      e.preventDefault(); e.stopPropagation();
      root.classList.contains('mobile-open') ? close() : open();
    });
    side.addEventListener('click', function (e) {
      if (mobile() && e.target.closest('a[href]')) close();
    });
    document.addEventListener('click', function (e) {
      if (root.classList.contains('mobile-open') && !side.contains(e.target) && !toggle.contains(e.target)) close();
    });
    document.addEventListener('keydown', function (e) {
      if (root.classList.contains('mobile-open') && e.key === 'Escape') { close(); toggle.focus(); }
    });
    window.addEventListener('resize', function () { if (!mobile()) close(); });
  });

  /* Motyw: automatycznie 22:00–06:00, ręczna zmiana przyciskiem. */
  var manualTheme = null;
  function isNight() { var h = new Date().getHours(); return h >= 22 || h < 6; }
  function applyTheme() {
    var dark = manualTheme === null ? isNight() : manualTheme;
    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
    document.querySelectorAll('[data-i24-theme-toggle]').forEach(function (btn) {
      btn.innerHTML = dark ? '☀️ <span>Tryb jasny</span>' : '🌙 <span>Tryb ciemny</span>';
      btn.setAttribute('aria-pressed', dark ? 'true' : 'false');
    });
  }
  var themeHosts = [document.querySelector('.admin-top-right'), document.querySelector('.client-top-right')];
  themeHosts.forEach(function (host) {
    if (!host || host.querySelector('[data-i24-theme-toggle]')) return;
    var btn = document.createElement('button');
    btn.type = 'button'; btn.className = 'i24-theme-toggle'; btn.setAttribute('data-i24-theme-toggle', '');
    btn.setAttribute('aria-label', 'Przełącz jasny lub ciemny motyw');
    btn.addEventListener('click', function () { manualTheme = !(document.documentElement.getAttribute('data-theme') === 'dark'); applyTheme(); });
    host.insertBefore(btn, host.firstChild);
  });
  applyTheme();
  window.setInterval(function () { if (manualTheme === null) applyTheme(); }, 60000);

  /* Grupowe menu administratora. */
  var admin = document.getElementById('adminShell');
  if (admin) {
    var groups = Array.prototype.slice.call(admin.querySelectorAll('.admin-nav-group'));
    var expand = admin.querySelector('[data-nav-expand]');
    var collapse = admin.querySelector('[data-nav-collapse]');
    if (expand) expand.addEventListener('click', function () { groups.forEach(function (g) { g.open = true; }); });
    if (collapse) collapse.addEventListener('click', function () { groups.forEach(function (g) { g.open = false; }); });
  }

  /* Responsywne etykiety tabel. */
  document.querySelectorAll('.admin-main table.table, .client-main table.table').forEach(function (table) {
    var rows = Array.prototype.slice.call(table.querySelectorAll('tr'));
    var header = rows.find(function (row) { return row.querySelector('th'); });
    if (!header) return;
    var labels = Array.prototype.slice.call(header.querySelectorAll('th')).map(function (cell) { return (cell.textContent || '').trim().replace(/\s+/g, ' '); });
    if (labels.filter(Boolean).length < 2) return;
    rows.forEach(function (row) {
      if (row === header) return;
      Array.prototype.slice.call(row.querySelectorAll('td')).forEach(function (cell, i) {
        if (!cell.hasAttribute('colspan') && labels[i] && !cell.hasAttribute('data-label')) cell.setAttribute('data-label', labels[i]);
      });
    });
    table.classList.add('i24-responsive-table');
  });
})();
