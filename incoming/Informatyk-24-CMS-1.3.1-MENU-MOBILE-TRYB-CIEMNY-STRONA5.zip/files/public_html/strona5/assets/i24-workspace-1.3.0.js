/* Informatyk-24 CMS 1.3.0 — mobilne menu, dostępność i responsywne tabele */
(function () {
  'use strict';

  const roots = [
    { id: 'adminShell', side: '.admin-sidebar', toggle: '.admin-mobile-toggle', kind: 'admin' },
    { id: 'clientShell', side: '.client-sidebar', toggle: '.client-toggle', kind: 'client' }
  ];

  function isMobile() {
    return window.matchMedia('(max-width: 850px)').matches;
  }

  roots.forEach(function (config) {
    const root = document.getElementById(config.id);
    if (!root) return;
    const sidebar = root.querySelector(config.side);
    const toggle = root.querySelector(config.toggle);
    if (!sidebar || !toggle) return;

    toggle.setAttribute('aria-expanded', 'false');
    toggle.setAttribute('aria-controls', sidebar.id || (config.kind + 'Sidebar'));

    const close = document.createElement('button');
    close.type = 'button';
    close.className = 'i24-mobile-menu-close';
    close.setAttribute('aria-label', 'Zamknij menu');
    close.textContent = '×';
    sidebar.insertBefore(close, sidebar.firstChild);

    const backdrop = document.createElement('button');
    backdrop.type = 'button';
    backdrop.className = 'i24-mobile-backdrop';
    backdrop.setAttribute('aria-label', 'Zamknij menu');
    backdrop.setAttribute('tabindex', '-1');
    backdrop.setAttribute('aria-hidden', 'true');
    root.appendChild(backdrop);

    let previousFocus = null;
    function setOpen(open) {
      if (!isMobile() && open) return;
      if (open) {
        previousFocus = document.activeElement;
        root.classList.add('mobile-open');
        document.documentElement.classList.add('i24-menu-open');
        document.body.classList.add('i24-menu-open');
        toggle.setAttribute('aria-expanded', 'true');
        toggle.setAttribute('aria-label', 'Zamknij menu');
        window.requestAnimationFrame(function () { close.focus(); });
      } else {
        root.classList.remove('mobile-open');
        document.documentElement.classList.remove('i24-menu-open');
        document.body.classList.remove('i24-menu-open');
        toggle.setAttribute('aria-expanded', 'false');
        toggle.setAttribute('aria-label', 'Otwórz menu');
        if (previousFocus && typeof previousFocus.focus === 'function') previousFocus.focus();
      }
    }

    toggle.addEventListener('click', function (event) {
      if (!isMobile()) return;
      event.preventDefault();
      event.stopPropagation();
      setOpen(!root.classList.contains('mobile-open'));
    });
    close.addEventListener('click', function () { setOpen(false); });
    backdrop.addEventListener('click', function () { setOpen(false); });

    sidebar.addEventListener('click', function (event) {
      const link = event.target.closest('a[href]');
      if (link && isMobile()) setOpen(false);
    });

    document.addEventListener('keydown', function (event) {
      if (!root.classList.contains('mobile-open')) return;
      if (event.key === 'Escape') {
        event.preventDefault();
        setOpen(false);
        return;
      }
      if (event.key === 'Tab') {
        const focusable = Array.from(sidebar.querySelectorAll('a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])'))
          .filter(function (element) { return element.getClientRects().length > 0; });
        if (!focusable.length) return;
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault(); last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault(); first.focus();
        }
      }
    });

    const observer = new MutationObserver(function () {
      if (root.classList.contains('mobile-open') && isMobile()) {
        toggle.setAttribute('aria-expanded', 'true');
      } else if (!root.classList.contains('mobile-open')) {
        toggle.setAttribute('aria-expanded', 'false');
      }
    });
    observer.observe(root, { attributes: true, attributeFilter: ['class'] });

    window.addEventListener('resize', function () {
      if (!isMobile() && root.classList.contains('mobile-open')) setOpen(false);
    }, { passive: true });
  });

  /* Grupy administratora: szybkie rozwijanie i zwijanie bez zmiany uprawnień. */
  const admin = document.getElementById('adminShell');
  if (admin) {
    const groups = Array.from(admin.querySelectorAll('.admin-nav-group'));
    const expand = admin.querySelector('[data-nav-expand]');
    const collapse = admin.querySelector('[data-nav-collapse]');
    if (expand) expand.addEventListener('click', function () { groups.forEach(function (group) { group.open = true; }); });
    if (collapse) collapse.addEventListener('click', function () { groups.forEach(function (group) { group.open = false; }); });
  }

  /* Na małych ekranach klasyczne tabele otrzymują etykiety pól i układ kart. */
  document.querySelectorAll('.admin-main table.table, .client-main table.table').forEach(function (table) {
    const rows = Array.from(table.querySelectorAll('tr'));
    const headerRow = rows.find(function (row) { return row.querySelector('th'); });
    if (!headerRow) return;
    const labels = Array.from(headerRow.querySelectorAll('th')).map(function (cell) {
      return (cell.textContent || '').trim().replace(/\s+/g, ' ');
    });
    if (labels.filter(Boolean).length < 2) return;
    rows.forEach(function (row) {
      if (row === headerRow) return;
      Array.from(row.querySelectorAll('td')).forEach(function (cell, index) {
        if (!cell.hasAttribute('colspan') && labels[index] && !cell.hasAttribute('data-label')) {
          cell.setAttribute('data-label', labels[index]);
        }
      });
    });
    table.classList.add('i24-responsive-table');
  });
})();
