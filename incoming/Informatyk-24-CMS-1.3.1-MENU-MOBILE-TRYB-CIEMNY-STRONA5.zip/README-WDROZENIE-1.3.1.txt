INFORMATYK-24 CMS STRONA5 — WERSJA 1.3.1

Wdrożenie:
1. Wykonaj kopię aktualnych plików.
2. Zawartość katalogu files/ wgraj z zachowaniem ścieżek na serwer.
3. Nie zmieniaj .env ani konfiguracji bazy danych.
4. Wyczyść cache przeglądarki lub otwórz stronę w trybie prywatnym.
5. Sprawdź stronę główną na telefonie: przycisk ☰ powinien rozwinąć menu.
6. Sprawdź panel administratora i panel klienta: menu boczne powinno otwierać się po naciśnięciu ☰.
7. Przełącznik motywu znajduje się w górnej części strony; automatyczny harmonogram: ciemny 22:00–06:00, jasny 06:00–22:00.

Zmiany obejmują pliki frontendu i plik VERSION. Brak migracji SQL.
