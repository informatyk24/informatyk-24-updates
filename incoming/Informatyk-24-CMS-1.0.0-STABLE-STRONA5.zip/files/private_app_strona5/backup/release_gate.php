<?php
declare(strict_types=1);

/**
 * Informatyk-24 CMS 1.0.0 Stable
 * Final release gate: read-only technical checks plus explicit manual gates.
 * Never performs payment, restore, rollback, mail delivery or configuration changes.
 */
function i24ReleaseGateReport(PDO $db, string $private, string $publicIndex): array {
    $base = basename($private);
    if (!str_starts_with($base, 'private_app_')) throw new RuntimeException('Nie można rozpoznać środowiska aplikacji.');
    $env = substr($base, strlen('private_app_'));
    if (!preg_match('/^[A-Za-z0-9_-]+$/', $env)) throw new RuntimeException('Nieprawidłowa nazwa środowiska.');

    $checks = [];
    $add = static function(string $area, string $name, string $status, string $detail, string $kind = 'automatic') use (&$checks): void {
        $checks[] = ['area'=>$area, 'name'=>$name, 'status'=>$status, 'kind'=>$kind, 'detail'=>$detail];
    };

    $version = trim((string)@file_get_contents($private . '/VERSION'));
    $add('Wersja', 'Numer wydania', $version === '1.0.0' ? 'ok' : 'critical',
        'Wykryta wersja: ' . ($version !== '' ? $version : 'brak') . '; oczekiwano 1.0.0.');

    $config = App\Core\Config::get('app', []);
    if (!is_array($config)) $config = [];
    $appEnv = strtolower((string)($config['env'] ?? ''));
    $debug = (bool)($config['debug'] ?? true);
    $add('Konfiguracja', 'Tryb produkcyjny', ($appEnv === 'production' && !$debug) ? 'ok' : 'warning',
        'APP_ENV=' . ($appEnv ?: 'brak') . '; APP_DEBUG=' . ($debug ? 'true' : 'false') . '.');

    $https = ((!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off')
        || strtolower((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https');
    $add('Transport', 'HTTPS bieżącego żądania', $https ? 'ok' : 'warning', $https ? 'Żądanie dotarło przez HTTPS.' : 'HTTPS nie zostało potwierdzone dla bieżącego żądania.');

    $extensions = ['pdo_mysql','mbstring','json','openssl','fileinfo','zip'];
    $missing = array_values(array_filter($extensions, static fn($x) => !extension_loaded($x)));
    $phpOk = version_compare(PHP_VERSION, '8.1.0', '>=') && !$missing;
    $add('PHP', 'Wersja i wymagane rozszerzenia', $phpOk ? 'ok' : 'warning',
        'PHP ' . PHP_VERSION . '; brakujące rozszerzenia: ' . ($missing ? implode(', ', $missing) : 'brak') . '.');

    $publicRoot = dirname($private) . '/public_html/' . $env;
    $privateReal = realpath($private);
    $publicReal = realpath($publicRoot);
    $outside = $privateReal !== false && ($publicReal === false || !str_starts_with($privateReal, rtrim($publicReal, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR));
    $mode = $privateReal !== false ? (fileperms($privateReal) & 0777) : 0777;
    $privateOk = $outside && (($mode & 0077) === 0);
    $add('Bezpieczeństwo plików', 'Prywatny katalog aplikacji', $privateOk ? 'ok' : 'warning', 'Poza public_html=' . ($outside ? 'tak' : 'nie') . '; uprawnienia=' . sprintf('%04o', $mode) . '.');

    $publicEnv = $publicRoot . '/.env';
    $add('Bezpieczeństwo plików', 'Brak publicznego pliku .env', !file_exists($publicEnv) ? 'ok' : 'critical', !file_exists($publicEnv) ? 'Nie znaleziono publicznego pliku .env.' : 'Wykryto publiczny plik .env.');
    $privateEnv = $private . '/.env';
    if (is_file($privateEnv) && !is_link($privateEnv)) {
        $envMode = fileperms($privateEnv) & 0777;
        $add('Bezpieczeństwo plików', 'Prywatny plik .env', (($envMode & 0077) === 0) ? 'ok' : 'warning', 'Uprawnienia=' . sprintf('%04o', $envMode) . '.');
    } else {
        $add('Bezpieczeństwo plików', 'Prywatny plik .env', 'unknown', 'Brak zwykłego pliku .env; potwierdź, czy konfiguracja pochodzi ze zmiennych środowiskowych hostingu.', 'manual');
    }

    try {
        $charset = (string)$db->query('SELECT @@character_set_connection')->fetchColumn();
        $tables = (int)$db->query('SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE()')->fetchColumn();
        $driver = (string)$db->getAttribute(PDO::ATTR_DRIVER_NAME);
        $emulated = $db->getAttribute(PDO::ATTR_EMULATE_PREPARES);
        $native = $driver === 'mysql' && ($emulated === false || $emulated === 0 || $emulated === '0');
        $dbOk = $charset === 'utf8mb4' && $tables > 0 && $native;
        $add('Baza danych', 'Połączenie, charset, tabele i PDO', $dbOk ? 'ok' : 'warning', 'Sterownik=' . $driver . '; charset=' . $charset . '; tabele=' . $tables . '; native prepares=' . ($native ? 'tak' : 'nie') . '.');
    } catch (Throwable $e) {
        $add('Baza danych', 'Połączenie i parametry PDO', 'critical', 'Kontrola nie powiodła się: ' . substr($e->getMessage(), 0, 160));
    }

    $required = [
        'public_html/' . $env . '/index.php' => $publicIndex,
        'private_app_' . $env . '/backup/production_readiness.php' => $private . '/backup/production_readiness.php',
        'private_app_' . $env . '/backup/backup_manager.php' => $private . '/backup/backup_manager.php',
        'private_app_' . $env . '/backup/restore_manager.php' => $private . '/backup/restore_manager.php',
        'private_app_' . $env . '/updates/update_manager.php' => $private . '/updates/update_manager.php',
    ];
    $missingFiles = [];
    foreach ($required as $label => $path) if (!is_file($path)) $missingFiles[] = $label;
    $add('Integralność aplikacji', 'Kluczowe pliki wydania', !$missingFiles ? 'ok' : 'critical', !$missingFiles ? 'Wszystkie wymagane pliki kluczowych modułów istnieją.' : 'Brak: ' . implode(', ', $missingFiles) . '.');

    $index = is_file($publicIndex) ? (string)@file_get_contents($publicIndex) : '';
    $routeMarkers = ['/health', '/admin/backup', '/admin/updates', '/admin/production-readiness'];
    $missingRoutes = [];
    foreach ($routeMarkers as $marker) if ($index === '' || strpos($index, $marker) === false) $missingRoutes[] = $marker;
    $add('Integralność aplikacji', 'Punkty wejścia kluczowych modułów', !$missingRoutes ? 'ok' : 'warning', !$missingRoutes ? 'W pliku front controllera znaleziono znaczniki tras health, backup, aktualizacji i gotowości produkcyjnej.' : 'Nie znaleziono znaczników: ' . implode(', ', $missingRoutes) . '.');

    $backupRoot = dirname($private) . '/backups' . ($env === 'strona3' ? '' : '/' . $env);
    $backups = glob($backupRoot . '/informatyk24-full-*.zip') ?: [];
    usort($backups, static fn($a,$b) => (filemtime($b) ?: 0) <=> (filemtime($a) ?: 0));
    $latest = $backups[0] ?? null;
    $backupStatus = 'warning';
    $backupDetail = 'Nie znaleziono pełnej kopii ZIP.';
    if ($latest && is_file($latest . '.sha256')) {
        $sidecar = trim((string)@file_get_contents($latest . '.sha256'));
        $expected = strtolower((string)strtok($sidecar, " \t\r\n"));
        $actual = @hash_file('sha256', $latest);
        $hashOk = is_string($actual) && preg_match('/^[a-f0-9]{64}$/', $expected) && hash_equals($expected, strtolower($actual));
        $zipOk = false;
        if (class_exists(ZipArchive::class)) { $zip = new ZipArchive(); if ($zip->open($latest) === true) { $zipOk = ($zip->numFiles > 0); $zip->close(); } }
        $backupStatus = ($hashOk && $zipOk) ? 'ok' : 'critical';
        $backupDetail = basename($latest) . '; SHA-256=' . ($hashOk ? 'zgodna' : 'NIEZGODNA') . '; ZIP=' . ($zipOk ? 'otwieralny' : 'niepoprawny');
    }
    $add('Odzyskiwanie', 'Integralność najnowszego pełnego backupu', $backupStatus, $backupDetail);

    $cronFiles = ['backup_automation.php','backup_monitor.php','subscription_automation.php'];
    $cronMissing = [];
    foreach ($cronFiles as $f) if (!is_file($private . '/cron/' . $f)) $cronMissing[] = $f;
    $add('Automatyzacja', 'Pliki skryptów CRON', !$cronMissing ? 'ok' : 'warning', !$cronMissing ? 'Wszystkie trzy oczekiwane skrypty istnieją; harmonogram hostingu wymaga osobnego potwierdzenia.' : 'Brak: ' . implode(', ', $cronMissing) . '.');

    // Manual test results were explicitly confirmed by the platform administrator in the
    // conversation on 2026-11-14. These are attestations, not independently collected logs.
    $attestation = 'Potwierdzone przez administratora 2026-11-14; dowody źródłowe nie zostały dołączone do raportu.';
    $add('Płatności', 'Transakcja Tpay LIVE i webhook', 'ok', $attestation, 'manual_attestation');
    $add('Automatyzacja', 'Rzeczywiste uruchamianie trzech zadań CRON', 'ok', $attestation, 'manual_attestation');
    $add('Odzyskiwanie', 'Pełne odtworzenie backupu w środowisku testowym', 'ok', $attestation, 'manual_attestation');
    $add('Odzyskiwanie', 'Kontrolowany rollback aktualizacji', 'ok', $attestation, 'manual_attestation');
    $add('Powiadomienia', 'Dostarczenie poczty e-mail przez SMTP', 'ok', $attestation, 'manual_attestation');
    $add('Testy akceptacyjne', 'Rejestracja klienta, zamówienie i panel klienta', 'ok', $attestation, 'manual_attestation');
    $add('Testy akceptacyjne', 'Panel administratora: zamówienia, usługi i aktualizacje', 'ok', $attestation, 'manual_attestation');

    $counts = ['ok'=>0,'warning'=>0,'critical'=>0,'unknown'=>0];
    foreach ($checks as $c) $counts[$c['status']]++;
    $manualOpen = count(array_filter($checks, static fn($c) => in_array($c['kind'], ['manual','manual_attestation'], true) && $c['status'] !== 'ok'));
    $ready = $counts['critical'] === 0 && $counts['warning'] === 0 && $counts['unknown'] === 0;
    return [
        'schema'=>'i24-release-gate-v1', 'application'=>'Informatyk-24', 'application_version'=>$version,
        'environment'=>$env, 'generated_at'=>date(DATE_ATOM), 'mode'=>'read_only',
        'release_candidate'=>'1.0.0 Stable', 'release_ready'=>$ready,
        'summary'=>['passed'=>$counts['ok'],'warnings'=>$counts['warning'],'critical'=>$counts['critical'],'unknown'=>$counts['unknown'],'checks'=>count($checks),'manual_open'=>$manualOpen],
        'checks'=>$checks,
        'release_blockers'=>[],
        'manual_attestation'=>[
            'source'=>'Potwierdzenie administratora w rozmowie',
            'date'=>'2026-11-14',
            'evidence_attached'=>false,
            'note'=>'Wyniki testów ręcznych oznaczono jako potwierdzone przez administratora. Raport nie zawiera logów, identyfikatora transakcji ani protokołów testowych.'
        ],
        'limitations'=>[
            'Raport wykonuje wyłącznie kontrole odczytowe; nie wysyła płatności ani wiadomości e-mail.',
            'Otwieralność archiwum ZIP i zgodność SHA-256 nie dowodzą, że backup można poprawnie odtworzyć.',
            'Wykrycie plików CRON nie potwierdza ich rejestracji ani wykonania przez hosting.',
            'Wykrycie znaczników tras w index.php nie zastępuje testów HTTP wszystkich tras.',
            'Potwierdzenia testów ręcznych pochodzą od administratora i nie są niezależną weryfikacją. Raport nie jest certyfikacją bezpieczeństwa.'
        ]
    ];
}
