/* Informatyk-24 CMS 1.3.2 — menu mobilne i trwały tryb wyglądu */
(function () {
  'use strict';
  var mobile = function () { return window.matchMedia('(max-width: 850px)').matches; };

  [
    { id: 'adminShell', sidebar: '.admin-sidebar', toggle: '.admin-mobile-toggle' },
    { id: 'clientShell', sidebar: '.client-sidebar', toggle: '.client-toggle' }
  ].forEach(function (cfg) {
    var root = document.getElementById(cfg.id);
    if (!root) return;
    var side = root.querySelector(cfg.sidebar);
    var toggle = root.querySelector(cfg.toggle);
    if (!side || !toggle) return;
    if (!side.id) side.id = cfg.id + 'Sidebar';
    toggle.setAttribute('aria-controls', side.id);
    toggle.setAttribute('aria-expanded', 'false');
    function close() {
      root.classList.remove('mobile-open');
      document.documentElement.classList.remove('i24-menu-open');
      document.body.classList.remove('i24-menu-open');
      toggle.setAttribute('aria-expanded', 'false');
      toggle.setAttribute('aria-label', 'Otwórz menu');
    }
    function open() {
      if (!mobile()) return;
      root.classList.add('mobile-open');
      document.documentElement.classList.add('i24-menu-open');
      document.body.classList.add('i24-menu-open');
      toggle.setAttribute('aria-expanded', 'true');
      toggle.setAttribute('aria-label', 'Zamknij menu');
    }
    toggle.addEventListener('click', function (e) {
      if (!mobile()) return;
      e.preventDefault(); e.stopPropagation();
      root.classList.contains('mobile-open') ? close() : open();
    });
    side.addEventListener('click', function (e) {
      if (mobile() && e.target.closest('a[href]')) close();
    });
    document.addEventListener('click', function (e) {
      if (root.classList.contains('mobile-open') && !side.contains(e.target) && !toggle.contains(e.target)) close();
    });
    document.addEventListener('keydown', function (e) {
      if (root.classList.contains('mobile-open') && e.key === 'Escape') { close(); toggle.focus(); }
    });
    window.addEventListener('resize', function () { if (!mobile()) close(); });
  });

  /* Motyw: AUTO (22:00–06:00), CIEMNY, JASNY. Wybór jest zapamiętywany. */
  var key = 'i24-theme-preference';
  var modes = ['auto', 'dark', 'light'];
  var labels = { auto: 'Motyw: automatyczny', dark: 'Motyw: ciemny', light: 'Motyw: jasny' };
  function readMode() {
    try {
      var saved = window.localStorage.getItem(key);
      return modes.indexOf(saved) >= 0 ? saved : 'auto';
    } catch (_) { return 'auto'; }
  }
  var mode = readMode();
  function nightNow() {
    var d = new Date();
    var minutes = d.getHours() * 60 + d.getMinutes();
    return minutes >= 22 * 60 || minutes < 6 * 60;
  }
  function applyTheme() {
    var dark = mode === 'dark' || (mode === 'auto' && nightNow());
    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
    document.querySelectorAll('[data-i24-theme-toggle]').forEach(function (btn) {
      btn.textContent = labels[mode];
      btn.setAttribute('aria-pressed', mode === 'dark' ? 'true' : 'false');
      btn.setAttribute('title', 'Kliknij, aby przełączyć: automatyczny → ciemny → jasny');
    });
  }
  document.querySelectorAll('[data-i24-theme-toggle]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      mode = modes[(modes.indexOf(mode) + 1) % modes.length];
      try { window.localStorage.setItem(key, mode); } catch (_) {}
      applyTheme();
    });
  });
  applyTheme();
  window.setInterval(function () { if (mode === 'auto') applyTheme(); }, 30000);

  /* Responsywne etykiety tabel. */
  document.querySelectorAll('.admin-main table.table, .client-main table.table').forEach(function (table) {
    var rows = Array.prototype.slice.call(table.querySelectorAll('tr'));
    var header = rows.find(function (row) { return row.querySelector('th'); });
    if (!header) return;
    var labels = Array.prototype.slice.call(header.querySelectorAll('th')).map(function (cell) {
      return (cell.textContent || '').trim().replace(/\s+/g, ' ');
    });
    if (labels.filter(Boolean).length < 2) return;
    rows.forEach(function (row) {
      if (row === header) return;
      Array.prototype.slice.call(row.querySelectorAll('td')).forEach(function (cell, i) {
        if (!cell.hasAttribute('colspan') && labels[i] && !cell.hasAttribute('data-label')) cell.setAttribute('data-label', labels[i]);
      });
    });
    table.classList.add('i24-responsive-table');
  });
})();