<?php
declare(strict_types=1);

/**
 * Informatyk-24 CMS 0.23.42.0
 * Read-only production readiness report.
 * Does not change PHP/server settings, database schema or application data.
 */
function i24ProductionReadinessReport(PDO $db, string $private): array {
    $envName = basename($private);
    if (!str_starts_with($envName, 'private_app_')) {
        throw new RuntimeException('Nie można rozpoznać środowiska aplikacji.');
    }
    $env = substr($envName, strlen('private_app_'));
    if (!preg_match('/^[A-Za-z0-9_-]+$/', $env)) {
        throw new RuntimeException('Nieprawidłowa nazwa środowiska.');
    }

    $domainRoot = dirname($private);
    $publicRoot = $domainRoot . '/public_html/' . $env;
    $appConfig = App\Core\Config::get('app', []);
    if (!is_array($appConfig)) $appConfig = [];

    $checks = [];
    $add = static function(string $area, string $name, string $status, string $detail) use (&$checks): void {
        $checks[] = ['area'=>$area, 'name'=>$name, 'status'=>$status, 'detail'=>$detail];
    };

    $https = ((!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off')
        || strtolower((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https');
    $add('Transport', 'HTTPS bieżącego żądania', $https ? 'ok' : 'warning',
        $https ? 'Żądanie dotarło przez HTTPS.' : 'Bieżące żądanie nie potwierdza HTTPS; sprawdź konfigurację reverse proxy i certyfikat.');

    $appUrl = (string)($appConfig['url'] ?? '');
    $appUrlHttps = str_starts_with(strtolower($appUrl), 'https://');
    $add('Konfiguracja', 'Adres bazowy aplikacji', $appUrlHttps ? 'ok' : 'warning',
        $appUrlHttps ? 'APP_URL używa HTTPS.' : 'APP_URL nie jest adresem HTTPS lub nie został skonfigurowany.');

    $appEnv = strtolower((string)($appConfig['env'] ?? ''));
    $debug = (bool)($appConfig['debug'] ?? true);
    $prodConfigOk = ($appEnv === 'production' && !$debug);
    $add('Konfiguracja', 'Tryb produkcyjny i debug', $prodConfigOk ? 'ok' : 'warning',
        'APP_ENV=' . ($appEnv !== '' ? $appEnv : 'brak') . '; APP_DEBUG=' . ($debug ? 'true' : 'false') . '. Oczekiwano production i false.');

    $displayErrors = strtolower((string)ini_get('display_errors'));
    $exposePhp = strtolower((string)ini_get('expose_php'));
    $phpHardening = (in_array($displayErrors, ['', '0', 'off', 'false'], true)
        && in_array($exposePhp, ['', '0', 'off', 'false'], true));
    $add('PHP', 'Ukrywanie błędów i sygnatury PHP', $phpHardening ? 'ok' : 'warning',
        'display_errors=' . ($displayErrors !== '' ? $displayErrors : 'brak') . '; expose_php=' . ($exposePhp !== '' ? $exposePhp : 'brak') . '. W produkcji oba ustawienia powinny być wyłączone.');

    $requiredExtensions = ['pdo_mysql', 'mbstring', 'json', 'openssl', 'fileinfo', 'zip'];
    $missing = array_values(array_filter($requiredExtensions, static fn($ext) => !extension_loaded($ext)));
    $add('PHP', 'Wymagane rozszerzenia PHP', count($missing) === 0 ? 'ok' : 'warning',
        count($missing) === 0 ? 'Wszystkie wymagane rozszerzenia są dostępne: ' . implode(', ', $requiredExtensions) . '.' : 'Brak rozszerzeń: ' . implode(', ', $missing) . '.');

    $session = session_get_cookie_params();
    $sessionSecure = !empty($session['secure']);
    $sessionHttpOnly = !empty($session['httponly']);
    $sameSite = strtolower((string)($session['samesite'] ?? ''));
    $sessionOk = $sessionSecure && $sessionHttpOnly && in_array($sameSite, ['lax', 'strict'], true);
    $add('Bezpieczeństwo', 'Parametry ciasteczka sesji', $sessionOk ? 'ok' : 'warning',
        'secure=' . ($sessionSecure ? 'true' : 'false') . '; httponly=' . ($sessionHttpOnly ? 'true' : 'false') . '; samesite=' . ($sameSite !== '' ? $sameSite : 'brak') . '.');

    $privateReal = realpath($private);
    $publicReal = realpath($publicRoot);
    $privateOutsidePublic = $privateReal !== false && ($publicReal === false
        || !str_starts_with($privateReal, rtrim($publicReal, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR));
    $privatePerms = $privateReal !== false ? (fileperms($privateReal) & 0777) : 0;
    $privatePermsOk = $privateOutsidePublic && (($privatePerms & 0007) === 0);
    $add('Pliki', 'Prywatny katalog aplikacji', $privatePermsOk ? 'ok' : 'warning',
        $privateReal === false ? 'Nie można ustalić katalogu prywatnego.' :
        ('Poza public_html=' . ($privateOutsidePublic ? 'tak' : 'nie') . '; uprawnienia=' . sprintf('%04o', $privatePerms) . '.'));

    $publicEnv = $publicRoot . '/.env';
    $add('Pliki', 'Brak pliku .env w katalogu publicznym', !file_exists($publicEnv) ? 'ok' : 'critical',
        !file_exists($publicEnv) ? 'Nie znaleziono publicznego pliku .env.' : 'Wykryto plik .env w katalogu publicznym. Usuń go lub zablokuj dostęp natychmiast.');

    $privateEnv = $private . '/.env';
    if (is_file($privateEnv)) {
        $mode = fileperms($privateEnv) & 0777;
        $envSecure = !is_link($privateEnv) && (($mode & 0077) === 0);
        $add('Pliki', 'Prywatny plik .env', $envSecure ? 'ok' : 'warning',
            'Plik istnieje; uprawnienia=' . sprintf('%04o', $mode) . '. Oczekiwany brak dostępu grupy i innych.');
    } else {
        $add('Pliki', 'Prywatny plik .env', 'unknown',
            'Nie znaleziono prywatnego .env. Konfiguracja może pochodzić ze zmiennych środowiskowych hostingu; potwierdź to ręcznie.');
    }

    try {
        $dbVersion = (string)$db->query('SELECT VERSION()')->fetchColumn();
        $dbCharset = (string)$db->query('SELECT @@character_set_connection')->fetchColumn();
        $tableCount = (int)$db->query('SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE()')->fetchColumn();
        $driver = (string)$db->getAttribute(PDO::ATTR_DRIVER_NAME);
        $db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
        $emulation = $db->getAttribute(PDO::ATTR_EMULATE_PREPARES);
        $native = ($driver === 'mysql' && ($emulation === false || $emulation === 0 || $emulation === '0'));
        $add('Baza danych', 'Połączenie, charset i tabele', ($dbCharset === 'utf8mb4' && $tableCount > 0) ? 'ok' : 'warning',
            'MariaDB/MySQL=' . $dbVersion . '; charset=' . $dbCharset . '; tabele=' . $tableCount . '.');
        $add('Baza danych', 'Natywne prepared statements PDO', $native ? 'ok' : 'warning',
            $native ? 'Sterownik MySQL używa natywnych prepared statements.' : 'Nie udało się potwierdzić wyłączenia emulowanych prepared statements.');
    } catch (Throwable $e) {
        $add('Baza danych', 'Kontrola połączenia i konfiguracji PDO', 'critical',
            'Kontrola nie powiodła się: ' . substr($e->getMessage(), 0, 180));
    }

    $cronFiles = ['backup_automation.php', 'backup_monitor.php', 'subscription_automation.php'];
    $cronMissing = [];
    foreach ($cronFiles as $file) if (!is_file($private . '/cron/' . $file)) $cronMissing[] = $file;
    $add('Automatyzacja', 'Pliki zadań CRON', count($cronMissing) === 0 ? 'ok' : 'warning',
        count($cronMissing) === 0 ? 'Wszystkie oczekiwane skrypty CRON istnieją.' : 'Brak plików: ' . implode(', ', $cronMissing) . '. Samo istnienie plików nie potwierdza wpisów w harmonogramie hostingu.');

    $backupRoot = dirname($private) . '/backups' . ($env === 'strona3' ? '' : '/' . $env);
    $backupFiles = glob($backupRoot . '/informatyk24-full-*.zip') ?: [];
    usort($backupFiles, static fn($a, $b) => (filemtime($b) ?: 0) <=> (filemtime($a) ?: 0));
    $latestBackup = $backupFiles[0] ?? null;
    $backupOk = $latestBackup !== null && is_file($latestBackup . '.sha256');
    $add('Odzyskiwanie', 'Dostępność pełnej kopii i sumy SHA-256', $backupOk ? 'ok' : 'warning',
        $backupOk ? 'Znaleziono najnowszą pełną kopię i plik sumy kontrolnej: ' . basename($latestBackup) . '.' : 'Brak pełnej kopii z plikiem .sha256. Wykonaj kopię przed wdrożeniem produkcyjnym.');

    $tpayKeys = ['TPAY_MERCHANT_ID', 'TPAY_SECURITY_CODE'];
    $tpayPresent = 0;
    foreach ($tpayKeys as $key) if (getenv($key) !== false && trim((string)getenv($key)) !== '') $tpayPresent++;
    $add('Płatności', 'Konfiguracja Tpay', 'unknown',
        'Automatyczne potwierdzenie pominięte: sprawdź w panelu Tpay tryb sandbox/live, identyfikatory, podpis webhooka i adres powiadomień. Raport nie odczytuje ani nie ujawnia sekretów.');

    $phpVersionOk = version_compare(PHP_VERSION, '8.1.0', '>=');
    $add('PHP', 'Wersja PHP', $phpVersionOk ? 'ok' : 'warning',
        'Wykryta wersja PHP: ' . PHP_VERSION . '.');

    $checksCount = count($checks);
    $passed = count(array_filter($checks, static fn($c) => $c['status'] === 'ok'));
    $warnings = count(array_filter($checks, static fn($c) => $c['status'] === 'warning'));
    $critical = count(array_filter($checks, static fn($c) => $c['status'] === 'critical'));
    $unknown = count(array_filter($checks, static fn($c) => $c['status'] === 'unknown'));
    return [
        'schema'=>'i24-production-readiness-v1',
        'application'=>'Informatyk-24',
        'application_version'=>trim((string)@file_get_contents($private . '/VERSION')),
        'environment'=>$env,
        'generated_at'=>date(DATE_ATOM),
        'mode'=>'read_only',
        'summary'=>['passed'=>$passed,'warnings'=>$warnings,'critical'=>$critical,'unknown'=>$unknown,'checks'=>$checksCount],
        'checks'=>$checks,
        'limitations'=>[
            'Raport nie wykonuje transakcji Tpay, nie testuje webhooka i nie odczytuje sekretów.',
            'Obecność skryptów CRON nie potwierdza ich rejestracji w harmonogramie hostingu.',
            'Raport nie zmienia konfiguracji PHP, serwera, bazy danych ani uprawnień.',
            'Test rzeczywistego odtworzenia i rollback musi być wykonany na odizolowanym środowisku.',
            'Wynik OK oznacza pozytywną kontrolę techniczną, a nie certyfikację bezpieczeństwa.'
        ]
    ];
}
