<?php
declare(strict_types=1);

/**
 * Informatyk-24 CMS 0.23.41.0
 * Read-only resilience audit for update packages, rollback metadata and backups.
 * Does not install packages, restore databases, alter files, or change server settings.
 */
function i24ReliabilityAudit(PDO $db, string $private): array {
    $env = basename($private);
    if (!str_starts_with($env, 'private_app_')) throw new RuntimeException('Nie można rozpoznać środowiska.');
    $env = substr($env, strlen('private_app_'));
    if (!preg_match('/^[A-Za-z0-9_-]+$/', $env)) throw new RuntimeException('Nieprawidłowa nazwa środowiska.');

    $domainRoot = dirname($private);
    $backupRoot = $domainRoot . '/backups' . ($env === 'strona3' ? '' : '/' . $env);
    $updateRoot = $private . '/updates';
    $checks = [];
    $add = static function(string $area, string $name, string $status, string $detail) use (&$checks): void {
        $checks[] = ['area'=>$area, 'name'=>$name, 'status'=>$status, 'detail'=>$detail];
    };

    $publicRoot = $domainRoot . '/public_html/' . $env;
    $backupReal = realpath($backupRoot);
    $publicReal = realpath($publicRoot);
    $backupOutsidePublic = $backupReal !== false && ($publicReal === false || !str_starts_with($backupReal, rtrim($publicReal, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR));
    $add('Backup', 'Lokalizacja kopii poza katalogiem publicznym', $backupOutsidePublic ? 'ok' : 'warning',
        $backupReal === false ? 'Katalog kopii jeszcze nie istnieje.' : ($backupOutsidePublic ? 'Katalog kopii znajduje się poza public_html.' : 'Katalog kopii znajduje się w katalogu publicznym lub jego podkatalogu.'));
    $backupPerms = $backupReal !== false ? (fileperms($backupReal) & 0777) : 0;
    $backupPrivate = $backupReal !== false && !is_link($backupRoot) && (($backupPerms & 0077) === 0);
    $add('Backup', 'Uprawnienia katalogu kopii', $backupPrivate ? 'ok' : ($backupReal === false ? 'unknown' : 'warning'),
        $backupReal === false ? 'Brak katalogu do sprawdzenia.' : sprintf('Tryb katalogu: %04o; oczekiwane bez dostępu dla grupy i innych.', $backupPerms));

    $backupItems = [];
    if ($backupReal !== false && is_dir($backupReal)) {
        $files = glob($backupReal . '/informatyk24-*.zip') ?: [];
        usort($files, static fn($a,$b) => (filemtime($b) ?: 0) <=> (filemtime($a) ?: 0));
        foreach (array_slice($files, 0, 10) as $file) {
            $name = basename($file);
            $sidecar = $file . '.sha256';
            $expected = '';
            if (is_file($sidecar)) $expected = strtolower((string)(preg_split('/\s+/', trim((string)file_get_contents($sidecar)))[0] ?? ''));
            $actual = hash_file('sha256', $file);
            $hashOk = preg_match('/^[a-f0-9]{64}$/', $expected) === 1 && is_string($actual) && hash_equals($expected, strtolower($actual));
            $zipOk = false; $zipDetail = 'Brak rozszerzenia ZipArchive.';
            if (class_exists(ZipArchive::class)) {
                $zip = new ZipArchive();
                if ($zip->open($file, ZipArchive::CHECKCONS) === true) {
                    $zipOk = $zip->locateName('BACKUP-INFO.txt') !== false && $zip->locateName('database.sql') !== false;
                    $zipDetail = $zipOk ? 'ZIP otwiera się; zawiera metadane i dump SQL.' : 'ZIP otwiera się, ale brakuje wymaganych elementów.';
                    $zip->close();
                } else $zipDetail = 'Archiwum nie przechodzi ZipArchive::CHECKCONS.';
            }
            $backupItems[] = ['name'=>$name, 'size'=>(int)(filesize($file) ?: 0), 'modified'=>date(DATE_ATOM, (int)(filemtime($file) ?: time())),
                'sha256_ok'=>$hashOk, 'zip_ok'=>$zipOk, 'status'=>($hashOk && $zipOk) ? 'ok' : 'warning', 'detail'=>!is_file($sidecar) ? 'Brak pliku sumy SHA-256. '.$zipDetail : ($hashOk ? $zipDetail : 'Suma SHA-256 niezgodna. '.$zipDetail)];
        }
    }
    $backupValid = count($backupItems) > 0 && count(array_filter($backupItems, static fn($b)=>$b['status']==='warning')) === 0;
    $add('Backup', 'Integralność ostatnich kopii', $backupValid ? 'ok' : (count($backupItems) ? 'warning' : 'unknown'),
        count($backupItems) ? count(array_filter($backupItems, static fn($b)=>$b['status']==='ok')).'/'.count($backupItems).' ostatnich kopii przeszło kontrolę SHA-256 i ZIP.' : 'Nie znaleziono kopii do sprawdzenia.');

    $updateDirExists = is_dir($updateRoot) && !is_link($updateRoot);
    $updatePerms = $updateDirExists ? (fileperms($updateRoot) & 0777) : 0;
    $updatePrivate = $updateDirExists && (($updatePerms & 0077) === 0);
    $add('Aktualizacje', 'Prywatny katalog aktualizacji', $updatePrivate ? 'ok' : ($updateDirExists ? 'warning' : 'unknown'),
        $updateDirExists ? sprintf('Tryb katalogu: %04o.', $updatePerms) : 'Katalog aktualizacji nie istnieje.');
    $packageItems = [];
    if ($updateDirExists) {
        foreach (glob($updateRoot . '/package-*.json') ?: [] as $metaFile) {
            $meta = json_decode((string)file_get_contents($metaFile), true);
            if (!is_array($meta) || (string)($meta['target_environment'] ?? '') !== $env) continue;
            $id = preg_replace('/[^0-9A-Za-z-]/', '', (string)($meta['id'] ?? ''));
            if ($id === '') continue;
            $zipFile = $updateRoot . '/package-' . $id . '.zip';
            $metaHash = strtolower((string)($meta['sha256'] ?? ''));
            $actualHash = is_file($zipFile) ? hash_file('sha256', $zipFile) : false;
            $hashOk = is_string($actualHash) && preg_match('/^[a-f0-9]{64}$/', $metaHash) === 1 && hash_equals($metaHash, strtolower($actualHash));
            $packageOk = false; $packageDetail = is_file($zipFile) ? 'Nie zweryfikowano formatu paczki.' : 'Brak archiwum ZIP paczki.';
            if ($hashOk && function_exists('i24UpdateValidateZip')) {
                try {
                    $validated = i24UpdateValidateZip($zipFile, $env, true);
                    $packageOk = (string)($validated['manifest']['version'] ?? '') === (string)($meta['version'] ?? '');
                    $packageDetail = $packageOk ? 'SHA-256, manifest, ścieżki i pliki paczki są zgodne.' : 'Numer wersji w metadanych różni się od manifestu.';
                } catch (Throwable $e) { $packageDetail = 'Walidacja paczki nie powiodła się: '.substr($e->getMessage(),0,220); }
            } elseif (!$hashOk) $packageDetail = 'Brak zgodności sumy SHA-256 metadanych i archiwum.';
            $rollbackOk = true; $rollbackDetail = 'Paczka nie wymaga kontroli rollback (nie jest oznaczona jako zainstalowana).';
            if (($meta['status'] ?? '') === 'installed' || !empty($meta['rollback_dir'])) {
                $rollbackDir = $updateRoot . '/' . basename((string)($meta['rollback_dir'] ?? ''));
                $rollbackFile = $rollbackDir . '/rollback.json';
                $rollback = is_file($rollbackFile) ? json_decode((string)file_get_contents($rollbackFile), true) : null;
                $rollbackOk = is_array($rollback) && (string)($rollback['environment'] ?? '') === $env && is_array($rollback['files'] ?? null);
                if ($rollbackOk) {
                    foreach ($rollback['files'] as $item) {
                        $rel = (string)($item['path'] ?? '');
                        if (!function_exists('i24UpdateAllowedPath') || !i24UpdateAllowedPath($rel, $env)) { $rollbackOk = false; break; }
                        if (!empty($item['existed'])) {
                            $saved = $rollbackDir . '/' . basename((string)($item['backup'] ?? ''));
                            if (!is_file($saved) || is_link($saved)) { $rollbackOk = false; break; }
                        }
                    }
                }
                $rollbackDetail = $rollbackOk ? 'Metadane rollback i wymagane kopie plików są dostępne.' : 'Brak lub niespójne metadane rollback albo brak zabezpieczonego pliku.';
            }
            $packageItems[] = ['version'=>(string)($meta['version'] ?? '—'), 'status'=>(string)($meta['status'] ?? 'unknown'),
                'sha256_ok'=>$hashOk, 'package_ok'=>$packageOk, 'rollback_ok'=>$rollbackOk,
                'result'=>($hashOk && $packageOk && $rollbackOk) ? 'ok' : 'warning', 'detail'=>$packageDetail.' '.$rollbackDetail];
        }
    }
    $packagesValid = count($packageItems) === 0 || count(array_filter($packageItems, static fn($p)=>$p['result']==='warning')) === 0;
    $add('Aktualizacje', 'Integralność zarejestrowanych paczek', $packagesValid ? 'ok' : 'warning',
        count($packageItems) ? count(array_filter($packageItems, static fn($p)=>$p['result']==='ok')).'/'.count($packageItems).' paczek przeszło kontrolę SHA-256, manifestu i rollback.' : 'Brak zarejestrowanych paczek do sprawdzenia.');

    $journal = $updateRoot . '/deployment-journal.jsonl';
    $journalOk = !is_file($journal) || is_readable($journal);
    $journalDetail = 'Dziennik nie istnieje — brak danych do kontroli.';
    if (is_file($journal) && is_readable($journal)) {
        $lines = file($journal, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [];
        $bad = 0; foreach (array_slice($lines, -500) as $line) { $row = json_decode($line, true); if (!is_array($row) || (isset($row['environment']) && (string)$row['environment'] !== $env)) $bad++; }
        $journalOk = $bad === 0; $journalDetail = 'Sprawdzono '.min(count($lines),500).' ostatnich wpisów; niepoprawne wpisy: '.$bad.'.';
    }
    $add('Aktualizacje', 'Czytelność i spójność dziennika wdrożeń', $journalOk ? 'ok' : 'warning', $journalDetail);

    $source = (string)@file_get_contents($private . '/updates/update_manager.php');
    $hasLock = str_contains($source, "flock(") && str_contains($source, "LOCK_EX | LOCK_NB");
    $hasAtomic = str_contains($source, 'i24UpdateWriteAtomic') && str_contains($source, 'rename($tmp, $path)');
    $add('Aktualizacje', 'Blokada współbieżnych operacji i zapis atomowy', ($hasLock && $hasAtomic) ? 'ok' : 'warning',
        ($hasLock ? 'Wykryto blokadę operacji. ' : 'Brak rozpoznanej blokady operacji. ').($hasAtomic ? 'Wykryto zapis atomowy.' : 'Brak rozpoznanego zapisu atomowego.'));

    return [
        'schema'=>'i24-resilience-audit-v1', 'generated_at'=>date(DATE_ATOM), 'environment'=>$env,
        'application_version'=>trim((string)@file_get_contents($private.'/VERSION')),
        'mode'=>'read_only', 'summary'=>[
            'passed'=>count(array_filter($checks, static fn($c)=>$c['status']==='ok')),
            'warnings'=>count(array_filter($checks, static fn($c)=>$c['status']==='warning')),
            'unknown'=>count(array_filter($checks, static fn($c)=>$c['status']==='unknown')),
            'checks'=>count($checks)
        ],
        'checks'=>$checks, 'backups'=>$backupItems, 'update_packages'=>$packageItems,
        'limitations'=>[
            'Kontrola ZIP i SHA-256 nie zastępuje rzeczywistego odtworzenia kopii w osobnym środowisku.',
            'Integralność rollback jest sprawdzana na podstawie metadanych i obecności kopii plików; nie wykonuje rollbacku.',
            'Nie symuluje przerwania aktualizacji ani nie modyfikuje plików, bazy danych lub konfiguracji serwera.',
            'Walidacja paczek korzysta z tego samego walidatora, którego używa instalator.'
        ]
    ];
}
