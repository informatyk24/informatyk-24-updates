<?php
declare(strict_types=1);

/**
 * Informatyk-24 CMS Update Manager
 * File-only, environment-bound updates. Database migrations are deliberately not auto-executed.
 * v0.23.33.0: deployment journal dashboard and downloadable structured JSON operation reports.
 * v0.23.32.0: one-click central installation with verified package, backup and rollback.
 * v0.23.30.1: bypass stale GitHub raw CDN responses in central update checks.
 * v0.23.15.10: Update Manager dashboard with package health, latest deployment, and archive integrity overview.
 * v0.23.15.9: advanced package search across release notes, date/status filters, and CSV export of package history.
 * v0.23.11.58: canonical paths, symlink checks, operation lock and atomic VERSION writes.
 */
function i24UpdateEnv(): string {
    $base = dirname(__DIR__);
    $name = basename($base);
    if (!str_starts_with($name, 'private_app_')) throw new RuntimeException('Nie można rozpoznać środowiska.');
    $env = substr($name, 12);
    if ($env === '' || !preg_match('/^[A-Za-z0-9_-]+$/', $env)) throw new RuntimeException('Nieprawidłowe środowisko.');
    return $env;
}
function i24UpdateRoot(): string {
    $p = dirname(__DIR__) . '/updates';
    if (!is_dir($p) && !mkdir($p, 0700, true) && !is_dir($p)) throw new RuntimeException('Nie można utworzyć katalogu aktualizacji.');
    @chmod($p, 0700);
    $deny = $p . '/.htaccess';
    if (!is_file($deny)) file_put_contents($deny, "Require all denied\nDeny from all\n");
    return $p;
}
function i24UpdateVersion(): string {
    $p = dirname(__DIR__) . '/VERSION';
    $v = is_file($p) ? trim((string)file_get_contents($p)) : '';
    return preg_match('/^\d+\.\d+\.\d+(?:\.\d+)?$/', $v) ? $v : '0.23.27.0';
}
function i24UpdateWriteAtomic(string $path, string $contents, int $mode = 0640): void {
    $dir = dirname($path);
    if (!is_dir($dir) || is_link($path)) throw new RuntimeException('Niebezpieczna ścieżka zapisu.');
    $tmp = $dir . '/.i24tmp-' . bin2hex(random_bytes(8));
    if (file_put_contents($tmp, $contents, LOCK_EX) === false) throw new RuntimeException('Nie można zapisać pliku tymczasowego.');
    @chmod($tmp, $mode);
    if (!rename($tmp, $path)) { @unlink($tmp); throw new RuntimeException('Nie można atomowo zapisać pliku.'); }
    @chmod($path, $mode);
}
function i24UpdateAssertSafeDestination(string $domainRoot, string $relativePath, string $env): string {
    if (!i24UpdateAllowedPath($relativePath, $env) || str_contains($relativePath, '\\')) {
        throw new RuntimeException('Niedozwolona ścieżka docelowa.');
    }
    $root = realpath($domainRoot);
    if ($root === false || is_link($domainRoot)) throw new RuntimeException('Nie można potwierdzić katalogu głównego aplikacji.');
    $parts = explode('/', $relativePath);
    $cursor = $root;
    for ($i = 0; $i < count($parts) - 1; $i++) {
        $cursor .= DIRECTORY_SEPARATOR . $parts[$i];
        if (is_link($cursor)) throw new RuntimeException('Wykryto dowiązanie symboliczne w ścieżce aktualizacji.');
        if (file_exists($cursor) && !is_dir($cursor)) throw new RuntimeException('Element ścieżki nie jest katalogiem.');
        if (!file_exists($cursor)) break;
        $resolved = realpath($cursor);
        if ($resolved === false || !str_starts_with($resolved, $root . DIRECTORY_SEPARATOR)) {
            throw new RuntimeException('Ścieżka aktualizacji wychodzi poza katalog aplikacji.');
        }
    }
    $dest = $root . DIRECTORY_SEPARATOR . implode(DIRECTORY_SEPARATOR, $parts);
    if (is_link($dest)) throw new RuntimeException('Plik docelowy jest dowiązaniem symbolicznym.');
    return $dest;
}
function i24UpdateAllowedPath(string $path, string $env): bool {
    $path = str_replace('\\', '/', $path);
    if ($path === '' || str_contains($path, "\0") || str_starts_with($path, '/') ||
        preg_match('/^[A-Za-z]:/', $path) || preg_match('~(^|/)\.\.?(/|$)~', $path)) return false;
    if (preg_match('~(^|/)(\.env(?:\..*)?|\.htaccess|\.user\.ini|composer\.(json|lock))$~i', $path)) return false;
    // Permit only this dashboard PHP file; all other updates storage remains blocked.
    $allowedUpdateDashboard = 'private_app_' . $env . '/updates/update_manager.php';
    if ($path === $allowedUpdateDashboard) return true;
    if (preg_match('~(^|/)(storage|uploads|backups|updates|logs|cache)(/|$)~i', $path)) return false;
    if ($path === 'public_html/' . $env . '/index.php') return true;
    if (str_starts_with($path, 'public_html/' . $env . '/assets/')) return true;
    if (str_starts_with($path, 'private_app_' . $env . '/app/')) return true;
    if (str_starts_with($path, 'private_app_' . $env . '/backup/')) return true;
    if (str_starts_with($path, 'private_app_' . $env . '/cron/')) return true;
    if (str_starts_with($path, 'private_app_' . $env . '/database/migrations/')) return true;
    if ($path === 'private_app_' . $env . '/VERSION') return true;
    return false;
}
function i24UpdateValidateZip(string $file, string $env, bool $allowDowngrade = false): array {
    if (!class_exists(ZipArchive::class)) throw new RuntimeException('Brak rozszerzenia ZipArchive.');
    $z = new ZipArchive();
    if ($z->open($file) !== true) throw new RuntimeException('Nie można otworzyć paczki ZIP.');
    try {
        $raw = $z->getFromName('release.json');
        if (!is_string($raw)) throw new RuntimeException('Paczka nie zawiera release.json.');
        $manifest = json_decode($raw, true, 32, JSON_THROW_ON_ERROR);
        if (!is_array($manifest) || ($manifest['format'] ?? '') !== 'i24-update-v1') throw new RuntimeException('Nieobsługiwany format paczki.');
        if (($manifest['target_environment'] ?? '') !== $env) throw new RuntimeException('Paczka jest przeznaczona dla innego środowiska. Oczekiwano: ' . $env . '.');
        $version = (string)($manifest['version'] ?? '');
        if (!preg_match('/^\d+\.\d+\.\d+(?:\.\d+)?$/', $version)) throw new RuntimeException('Nieprawidłowy numer wersji.');
        if (!$allowDowngrade && version_compare($version, i24UpdateVersion(), '<=')) throw new RuntimeException('Wersja paczki nie jest nowsza od zainstalowanej.');
        $files = $manifest['files'] ?? null;
        if (!is_array($files) || count($files) < 1 || count($files) > 300) throw new RuntimeException('Nieprawidłowa lista plików w paczce.');
        $total = 0; $seen = [];
        foreach ($files as $entry) {
            if (!is_array($entry)) throw new RuntimeException('Nieprawidłowy wpis manifestu.');
            $path = (string)($entry['path'] ?? '');
            $sha = strtolower((string)($entry['sha256'] ?? ''));
            if ($path !== str_replace('\\', '/', $path) || !i24UpdateAllowedPath($path, $env)) throw new RuntimeException('Niedozwolona ścieżka w paczce: ' . $path);
            if (isset($seen[$path])) throw new RuntimeException('Powtórzony plik w manifeście: ' . $path);
            $seen[$path] = true;
            if (!preg_match('/^[a-f0-9]{64}$/', $sha)) throw new RuntimeException('Nieprawidłowa suma SHA-256.');
            $entryName = 'files/' . $path;
            $stat = $z->statName($entryName);
            if (!$stat || (int)$stat['size'] > 10 * 1024 * 1024) throw new RuntimeException('Brak pliku lub zbyt duży plik: ' . $path);
            $total += (int)$stat['size'];
            if ($total > 50 * 1024 * 1024) throw new RuntimeException('Paczka przekracza limit 50 MB.');
            $data = $z->getFromName($entryName);
            if (!is_string($data) || !hash_equals($sha, hash('sha256', $data))) throw new RuntimeException('Nie zgadza się SHA-256 pliku: ' . $path);
        }
        if ($z->numFiles > count($files) + 1) throw new RuntimeException('Paczka zawiera nieoczekiwane dodatkowe pliki.');
        return ['manifest'=>$manifest, 'files'=>$files, 'count'=>count($files), 'size'=>$total];
    } finally { $z->close(); }
}
/** Keep one active package row marked installed; never delete or modify ZIP archives here. */
function i24UpdateSyncPackageStatuses(string $root, string $env, string $activeVersion, ?string $activeId = null, ?string $rolledBackId = null): void {
    $files = glob($root . '/package-*.json') ?: [];
    $candidateId = $activeId;
    if ($candidateId === null) {
        $candidates = [];
        foreach ($files as $file) {
            $meta = json_decode((string)@file_get_contents($file), true);
            if (!is_array($meta) || (string)($meta['target_environment'] ?? '') !== $env || (string)($meta['version'] ?? '') !== $activeVersion) continue;
            $candidates[] = ['file'=>$file, 'meta'=>$meta];
        }
        usort($candidates, static function(array $a, array $b): int {
            return strcmp((string)($b['meta']['installed_at'] ?? $b['meta']['uploaded_at'] ?? ''), (string)($a['meta']['installed_at'] ?? $a['meta']['uploaded_at'] ?? ''));
        });
        if ($candidates) $candidateId = (string)($candidates[0]['meta']['id'] ?? '');
    }
    foreach ($files as $file) {
        $meta = json_decode((string)@file_get_contents($file), true);
        if (!is_array($meta) || (string)($meta['target_environment'] ?? '') !== $env) continue;
        $id = (string)($meta['id'] ?? '');
        $oldStatus = (string)($meta['status'] ?? 'unknown');
        $newStatus = $oldStatus;
        if ($rolledBackId !== null && $id === $rolledBackId) {
            $newStatus = 'rolled_back';
        } elseif ($candidateId !== null && $id === $candidateId) {
            $newStatus = 'installed';
        } elseif ($oldStatus === 'installed') {
            $newStatus = 'superseded';
        }
        if ($newStatus !== $oldStatus) {
            $meta['status'] = $newStatus;
            $meta['status_updated_at'] = date(DATE_ATOM);
            $json = json_encode($meta, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);
            i24UpdateWriteAtomic($file, $json, 0600);
        }
    }
}
/** Snapshot package metadata for the target environment before changing statuses. */
function i24UpdateSnapshotPackageStatuses(string $root, string $env): array {
    $snapshot = [];
    foreach (glob($root . '/package-*.json') ?: [] as $file) {
        $raw = @file_get_contents($file);
        if (!is_string($raw)) throw new RuntimeException('Nie można odczytać historii paczek przed zmianą statusów.');
        $meta = json_decode($raw, true);
        if (!is_array($meta)) throw new RuntimeException('Nieprawidłowe metadane paczki: ' . basename($file));
        if ((string)($meta['target_environment'] ?? '') === $env) $snapshot[basename($file)] = $raw;
    }
    return $snapshot;
}

/** Restore the exact package metadata snapshot if installation finalization fails. */
function i24UpdateRestorePackageStatuses(string $root, array $snapshot): void {
    foreach ($snapshot as $name => $raw) {
        if (!preg_match('/^package-[0-9A-Za-z-]+\\.json$/', (string)$name) || !is_string($raw)) continue;
        i24UpdateWriteAtomic($root . '/' . $name, $raw, 0600);
    }
}

function i24UpdateRollbackDirectory(string $root, array $meta, string $id): string {
    $stored = (string)($meta['rollback_dir'] ?? '');
    if ($stored !== '' && preg_match('/^rollback-[0-9A-Za-z-]+$/', $stored) && is_file($root . '/' . $stored . '/rollback.json')) return $root . '/' . $stored;
    $legacy = $root . '/rollback-' . $id;
    if (is_file($legacy . '/rollback.json')) return $legacy;
    throw new RuntimeException('Nie znaleziono punktu wycofania dla tego wdrożenia.');
}

/** Normalize optional release notes from release.json; only plain text is accepted. */
function i24UpdateReleaseNotes($value): array {
    if (!is_array($value)) return ['summary'=>'', 'sections'=>[]];
    $clean = static function($text, int $max): string {
        if (!is_string($text)) return '';
        $text = trim(preg_replace('/[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F]/u', '', $text) ?? '');
        if (function_exists('mb_substr')) return mb_substr($text, 0, $max, 'UTF-8');
        return substr($text, 0, $max);
    };
    $summary = $clean($value['summary'] ?? '', 700);
    $sections = [];
    foreach (array_slice(is_array($value['sections'] ?? null) ? $value['sections'] : [], 0, 6) as $section) {
        if (!is_array($section)) continue;
        $title = $clean($section['title'] ?? '', 80);
        if ($title === '') continue;
        $items = [];
        foreach (array_slice(is_array($section['items'] ?? null) ? $section['items'] : [], 0, 10) as $item) {
            $item = $clean($item, 300);
            if ($item !== '') $items[] = $item;
        }
        if ($items) $sections[] = ['title'=>$title, 'items'=>$items];
    }
    return ['summary'=>$summary, 'sections'=>$sections];
}

/** Read release notes from stored metadata first, then from the retained original ZIP. */
function i24UpdateResolveHistoricalNotes(string $root, array $meta, string $id): array {
    $notes = i24UpdateReleaseNotes($meta['release_notes'] ?? null);
    $name = trim((string)($meta['release_name'] ?? ''));
    if ($notes['summary'] !== '' || $notes['sections']) return ['name'=>$name, 'notes'=>$notes, 'source'=>'metadata', 'files'=>[]];
    $zipPath = $root . '/package-' . $id . '.zip';
    if (!is_file($zipPath) || !class_exists(ZipArchive::class)) return ['name'=>$name, 'notes'=>$notes, 'source'=>'none', 'files'=>[]];
    $zip = new ZipArchive();
    if ($zip->open($zipPath) !== true) return ['name'=>$name, 'notes'=>$notes, 'source'=>'none', 'files'=>[]];
    try {
        $raw = $zip->getFromName('release.json');
        $manifest = is_string($raw) ? json_decode($raw, true) : null;
        if (is_array($manifest)) {
            if ($name === '') $name = trim((string)($manifest['name'] ?? $manifest['title'] ?? ''));
            $rawNotes = $manifest['release_notes'] ?? null;
            $normalized = i24UpdateReleaseNotes($rawNotes);
            if ($normalized['summary'] === '' && !$normalized['sections'] && is_array($manifest['notes'] ?? null)) {
                $items = [];
                foreach (array_slice($manifest['notes'], 0, 10) as $line) if (is_string($line) && trim($line) !== '') $items[] = trim($line);
                if ($items) $normalized['sections'] = [['title'=>'Informacje z manifestu', 'items'=>$items]];
            }
            if ($normalized['summary'] !== '' || $normalized['sections']) return ['name'=>$name, 'notes'=>$normalized, 'source'=>'archive-manifest', 'files'=>[]];
        }
        // Manual historical packages may carry a README instead of release.json.
        for ($i=0; $i<$zip->numFiles; $i++) {
            $stat = $zip->statIndex($i);
            $entry = (string)($stat['name'] ?? '');
            if (!preg_match('~(^|/)README[^/]*\.txt$~i', $entry)) continue;
            $readme = $zip->getFromIndex($i);
            if (!is_string($readme)) continue;
            $lines = preg_split('/\\r?\\n/', strip_tags($readme)) ?: [];
            $items = [];
            foreach ($lines as $line) {
                $line = trim(preg_replace('/\\s+/', ' ', $line));
                if ($line !== '' && !preg_match('/^(INFORMATYK-24|README|SHA256SUMS)/i', $line)) $items[] = mb_substr($line, 0, 280, 'UTF-8');
                if (count($items) >= 12) break;
            }
            if ($items) return ['name'=>$name, 'notes'=>['summary'=>'Odczytano instrukcję dołączoną do historycznego archiwum.', 'sections'=>[['title'=>'Informacje z README', 'items'=>$items]]], 'source'=>'archive-readme', 'files'=>[]];
        }
        $files = [];
        for ($i=0; $i<$zip->numFiles; $i++) {
            $entry = (string)($zip->getNameIndex($i) ?: '');
            if ($entry !== '' && !str_ends_with($entry, '/') && $entry !== 'release.json' && !preg_match('~(^|/)SHA256SUMS\\.txt$~i', $entry)) $files[] = $entry;
            if (count($files) >= 20) break;
        }
        return ['name'=>$name, 'notes'=>$notes, 'source'=>'archive-files', 'files'=>$files];
    } finally { $zip->close(); }
}

if (!function_exists('i24UpdateJournal')) {
    function i24UpdateJournal(string $root, array $event): bool {
        $privateName = basename(dirname($root));
        $event = array_merge(['at'=>date(DATE_ATOM), 'environment'=>str_starts_with($privateName, 'private_app_') ? substr($privateName, 12) : $privateName, 'event'=>'unknown'], $event);
        $line = json_encode($event, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);
        if (!is_string($line)) return false;
        $file = $root . '/deployment-journal.jsonl';
        $written = @file_put_contents($file, $line . "\n", FILE_APPEND|LOCK_EX);
        if ($written === false) { error_log('Informatyk-24: nie można zapisać dziennika wdrożeń.'); return false; }
        @chmod($file, 0600);
        return true;
    }
}

// Diagnostics helpers are guarded because this dashboard may be loaded independently
// from app/update_manager.php by the front controller.
if (!function_exists('i24UpdatePreflight')) {
    function i24UpdatePreflight(string $private, string $root): array {
        $checks = [];
        $zipAvailable = class_exists(ZipArchive::class);
        $backup = $private . '/backup';
        $checks[] = ['name'=>'PHP 8.1+', 'ok'=>version_compare(PHP_VERSION, '8.1.0', '>='), 'detail'=>PHP_VERSION];
        $checks[] = ['name'=>'ZipArchive', 'ok'=>$zipAvailable, 'detail'=>$zipAvailable?'Dostępne':'Brak rozszerzenia'];
        $updatesWritable = is_dir($root) && is_writable($root);
        $checks[] = ['name'=>'Katalog aktualizacji', 'ok'=>$updatesWritable, 'detail'=>$updatesWritable?'Zapis możliwy':'Brak prawa zapisu'];
        $backupWritable = is_dir($backup) && is_writable($backup);
        $checks[] = ['name'=>'Katalog backupów', 'ok'=>$backupWritable, 'detail'=>$backupWritable?'Zapis możliwy':'Brak prawa zapisu'];
        $backupModule = is_file($backup . '/backup_manager.php');
        $checks[] = ['name'=>'Moduł backupu', 'ok'=>$backupModule, 'detail'=>$backupModule?'Plik obecny':'Brak pliku'];
        return $checks;
    }
}
if (!function_exists('i24UpdateHealthProbe')) {
    function i24UpdateHealthProbe(PDO $db, string $private): array {
        $dbOk = false;
        try { $dbOk = $db->query('SELECT 1')->fetchColumn() !== false; } catch (Throwable $e) { $dbOk = false; }
        $checks = [['name'=>'Połączenie z bazą', 'ok'=>$dbOk, 'detail'=>$dbOk?'Zapytanie SELECT 1 wykonane':'Błąd zapytania PDO']];
        $v = trim((string)@file_get_contents($private . '/VERSION'));
        $versionOk = (bool)preg_match('/^\d+\.\d+\.\d+(?:\.\d+)?$/', $v);
        $checks[] = ['name'=>'Plik VERSION', 'ok'=>$versionOk, 'detail'=>$versionOk?$v:($v!==''?'Nieprawidłowy format':'Brak wersji')];
        $bootstrap = is_file($private . '/bootstrap.php');
        $checks[] = ['name'=>'Bootstrap', 'ok'=>$bootstrap, 'detail'=>$bootstrap?'Plik obecny':'Brak pliku'];
        return $checks;
    }
}


/**
 * Check the public GitHub update manifest. This action is read-only:
 * it never downloads or installs a package.
 */
function i24UpdateFetchRemoteText(string $url, int $maxBytes = 262144): string {
    if (!str_starts_with($url, 'https://raw.githubusercontent.com/informatyk24/informatyk-24-updates/')) {
        throw new RuntimeException('Niedozwolony adres repozytorium aktualizacji.');
    }
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        if ($ch === false) throw new RuntimeException('Nie można uruchomić klienta HTTPS.');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT => 'Informatyk-24-Update-Checker/1.0',
            CURLOPT_HTTPHEADER => ['Accept: application/json', 'Cache-Control: no-cache, no-store, max-age=0', 'Pragma: no-cache'],
        ]);
        $body = curl_exec($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        if (!is_string($body) || $status !== 200) {
            throw new RuntimeException('Nie udało się pobrać danych z GitHub (HTTP ' . $status . '). ' . substr($error, 0, 160));
        }
    } else {
        $context = stream_context_create(['http'=>[
            'method'=>'GET', 'timeout'=>10, 'ignore_errors'=>true,
            'header'=>"User-Agent: Informatyk-24-Update-Checker/1.0\r\nAccept: application/json\r\nCache-Control: no-cache, no-store, max-age=0\r\nPragma: no-cache\r\n"
        ], 'ssl'=>['verify_peer'=>true, 'verify_peer_name'=>true]]);
        $body = @file_get_contents($url, false, $context);
        $status = 0;
        foreach (($http_response_header ?? []) as $header) {
            if (preg_match('~^HTTP/\S+\s+(\d{3})~i', $header, $m)) $status = (int)$m[1];
        }
        if (!is_string($body) || $status !== 200) throw new RuntimeException('Nie udało się pobrać danych z GitHub (HTTP ' . $status . ').');
    }
    if (strlen($body) > $maxBytes) throw new RuntimeException('Odpowiedź repozytorium przekracza dozwolony rozmiar.');
    return $body;
}

function i24UpdateCheckCentral(string $env, string $installedVersion): array {
    $base = 'https://raw.githubusercontent.com/informatyk24/informatyk-24-updates/main/';
    // Cache-busting query prevents stale raw.githubusercontent.com/CDN responses.
    $cacheKey = (string)time();
    $raw = i24UpdateFetchRemoteText($base . 'manifest.json?nocache=' . rawurlencode($cacheKey), 65536);
    $manifest = json_decode($raw, true, 32, JSON_THROW_ON_ERROR);
    if (!is_array($manifest) || ($manifest['schema'] ?? '') !== 'i24-update-manifest-v1' ||
        ($manifest['product'] ?? '') !== 'Informatyk-24' ||
        ($manifest['channel'] ?? '') !== 'stable' ||
        ($manifest['target_environment'] ?? '') !== $env) {
        throw new RuntimeException('Manifest GitHub ma nieprawidłowy format, produkt, kanał lub środowisko.');
    }
    $latest = (string)($manifest['latest_version'] ?? '');
    if (!preg_match('/^\d+\.\d+\.\d+(?:\.\d+)?$/', $latest)) throw new RuntimeException('Manifest zawiera nieprawidłowy numer wersji.');
    $isNewer = version_compare($latest, $installedVersion, '>');
    $notes = [];
    if ($isNewer) {
        $changelogRaw = i24UpdateFetchRemoteText($base . 'changelog.json?nocache=' . rawurlencode($cacheKey), 196608);
        $changelog = json_decode($changelogRaw, true, 32, JSON_THROW_ON_ERROR);
        if (is_array($changelog) && ($changelog['schema'] ?? '') === 'i24-changelog-v1' && is_array($changelog['releases'] ?? null)) {
            foreach ($changelog['releases'] as $release) {
                if (is_array($release) && (string)($release['version'] ?? '') === $latest &&
                    (string)($release['target_environment'] ?? '') === $env) {
                    foreach (array_slice((array)($release['changes'] ?? []), 0, 20) as $change) {
                        if (is_string($change)) $notes[] = mb_substr($change, 0, 280, 'UTF-8');
                    }
                    break;
                }
            }
        }
    }
    return [
        'installed_version'=>$installedVersion,
        'latest_version'=>$latest,
        'update_available'=>$isNewer && !empty($manifest['release_available']) && is_string($manifest['package_url'] ?? null) && $manifest['package_url'] !== '' && is_string($manifest['package_sha256'] ?? null) && preg_match('/^[a-f0-9]{64}$/i', $manifest['package_sha256']) && is_numeric($manifest['package_size_bytes'] ?? null) && (int)$manifest['package_size_bytes'] > 0,
        'release_available'=>!empty($manifest['release_available']),
        'package_url'=>is_string($manifest['package_url'] ?? null) ? $manifest['package_url'] : '',
        'package_sha256'=>is_string($manifest['package_sha256'] ?? null) ? $manifest['package_sha256'] : '',
        'package_size_bytes'=>is_numeric($manifest['package_size_bytes'] ?? null) ? (int)$manifest['package_size_bytes'] : 0,
        'notes'=>$notes,
        'checked_at'=>date(DATE_ATOM),
    ];
}

/** Download a published GitHub release asset to a private temporary file. */
function i24UpdateDownloadAsset(string $url, string $destination, int $maxBytes): int {
    $parts = parse_url($url);
    if (!is_array($parts) || ($parts['scheme'] ?? '') !== 'https' || ($parts['host'] ?? '') !== 'github.com' ||
        !str_starts_with((string)($parts['path'] ?? ''), '/informatyk24/informatyk-24-updates/releases/download/')) {
        throw new RuntimeException('Adres paczki nie prowadzi do dozwolonego wydania GitHub.');
    }
    if (!function_exists('curl_init')) throw new RuntimeException('Pobieranie paczek wymaga rozszerzenia PHP cURL.');
    $out = @fopen($destination, 'xb');
    if (!$out) throw new RuntimeException('Nie można utworzyć tymczasowego pliku paczki.');
    $bytes = 0;
    $ch = curl_init($url);
    if ($ch === false) { fclose($out); @unlink($destination); throw new RuntimeException('Nie można uruchomić pobierania HTTPS.'); }
    curl_setopt_array($ch, [
        CURLOPT_FILE => $out, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 5,
        CURLOPT_CONNECTTIMEOUT => 10, CURLOPT_TIMEOUT => 120,
        CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_PROTOCOLS => CURLPROTO_HTTPS, CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTPS,
        CURLOPT_USERAGENT => 'Informatyk-24-Update-Manager/0.23.31.0',
        CURLOPT_HTTPHEADER => ['Accept: application/octet-stream', 'Cache-Control: no-cache'],
        CURLOPT_NOPROGRESS => false,
        CURLOPT_XFERINFOFUNCTION => static function($curl, $downloadTotal, $downloadNow, $uploadTotal, $uploadNow) use ($maxBytes) {
            return $downloadNow > $maxBytes ? 1 : 0;
        },
        CURLOPT_WRITEFUNCTION => static function($curl, $data) use ($out, &$bytes, $maxBytes) {
            $length = strlen($data);
            if ($length === 0 || $bytes + $length > $maxBytes) return 0;
            $written = fwrite($out, $data);
            if ($written === false) return 0;
            $bytes += $written;
            return $written;
        },
    ]);
    $ok = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $effective = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    $error = curl_error($ch);
    curl_close($ch);
    fflush($out); fclose($out);
    $final = parse_url($effective);
    $allowedFinalHost = is_array($final) && in_array(($final['host'] ?? ''), ['github.com','release-assets.githubusercontent.com','objects.githubusercontent.com'], true);
    if ($ok !== true || $status !== 200 || !$allowedFinalHost || $bytes < 1 || $bytes > $maxBytes) {
        @unlink($destination);
        throw new RuntimeException('Pobieranie paczki GitHub nie powiodło się (HTTP ' . $status . '). ' . substr($error, 0, 140));
    }
    return $bytes;
}

/** Re-fetch manifest, download asset, verify package hash and every ZIP entry, then store as validated. */
function i24UpdateDownloadCentralPackage(string $env, string $private, string $root): array {
    $check = i24UpdateCheckCentral($env, i24UpdateVersion());
    if (!$check['update_available'] || !$check['release_available']) throw new RuntimeException('Repozytorium nie udostępnia obecnie nowszej paczki.');
    $url = (string)$check['package_url'];
    $expectedHash = strtolower((string)$check['package_sha256']);
    $expectedSize = (int)($check['package_size_bytes'] ?? 0);
    if (!preg_match('/^[a-f0-9]{64}$/', $expectedHash)) throw new RuntimeException('Manifest nie zawiera prawidłowej sumy SHA-256 paczki.');
    if ($expectedSize < 1 || $expectedSize > 25 * 1024 * 1024) throw new RuntimeException('Manifest zawiera nieprawidłowy rozmiar paczki (limit 25 MB).');
    $tmp = $root . '/.download-' . bin2hex(random_bytes(8)) . '.zip';
    try {
        $actualSize = i24UpdateDownloadAsset($url, $tmp, 25 * 1024 * 1024);
        if ($actualSize !== $expectedSize) throw new RuntimeException('Rozmiar pobranej paczki nie zgadza się z manifestem.');
        $actualHash = hash_file('sha256', $tmp);
        if (!is_string($actualHash) || !hash_equals($expectedHash, strtolower($actualHash))) throw new RuntimeException('Suma SHA-256 pobranej paczki nie zgadza się z manifestem.');
        $validated = i24UpdateValidateZip($tmp, $env, false);
        if ((string)$validated['manifest']['version'] !== (string)$check['latest_version']) throw new RuntimeException('Wersja w ZIP nie zgadza się z manifestem centralnym.');
        $id = date('YmdHis') . '-' . bin2hex(random_bytes(4));
        $dest = $root . '/package-' . $id . '.zip';
        if (!rename($tmp, $dest)) throw new RuntimeException('Nie można przenieść zweryfikowanej paczki do katalogu aktualizacji.');
        @chmod($dest, 0600);
        $meta = [
            'id'=>$id, 'version'=>$validated['manifest']['version'], 'target_environment'=>$env,
            'uploaded_at'=>date(DATE_ATOM), 'downloaded_at'=>date(DATE_ATOM),
            'source'=>'github-central', 'file_count'=>$validated['count'], 'size'=>$validated['size'],
            'sha256'=>hash_file('sha256', $dest), 'status'=>'validated',
            'release_name'=>is_string($validated['manifest']['name'] ?? null) ? substr(trim($validated['manifest']['name']), 0, 120) : '',
            'release_notes'=>i24UpdateReleaseNotes($validated['manifest']['release_notes'] ?? null)
        ];
        $json = json_encode($meta, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);
        i24UpdateWriteAtomic($root . '/package-' . $id . '.json', $json, 0600);
        return ['id'=>$id, 'version'=>(string)$meta['version']];
    } finally { if (is_file($tmp)) @unlink($tmp); }
}

function i24UpdateHandle(PDO $db, string $path, string $method, string $private): void {
    if ($path !== '/admin/updates' && !str_starts_with($path, '/admin/updates/')) return;
    $u = requireUser($db); v06RequirePlatformAdmin($u);
    require_once $private . '/backup/backup_manager.php';
    $env = i24UpdateEnv(); $root = i24UpdateRoot();
    $notice = ''; $error = '';
    $centralCheck = null;
    if ($method === 'POST') {
        checkCsrf();
        $action = (string)($_POST['action'] ?? '');
        try {
            if (in_array($action, ['install', 'install_central_update', 'rollback'], true)) {
                $lockPath = $root . '/operation.lock';
                $lockHandle = @fopen($lockPath, 'c');
                if (!$lockHandle) throw new RuntimeException('Nie można otworzyć blokady operacji aktualizacji.');
                @chmod($lockPath, 0600);
                if (!flock($lockHandle, LOCK_EX | LOCK_NB)) {
                    fclose($lockHandle);
                    throw new RuntimeException('Inna operacja aktualizacji lub wycofania jest już wykonywana.');
                }
                // The lock is released automatically when this request ends.
            }
            if ($action === 'check_central_updates') {
                $centralCheck = i24UpdateCheckCentral($env, i24UpdateVersion());
                $notice = $centralCheck['update_available']
                    ? 'W repozytorium znaleziono nowszą wersję: ' . $centralCheck['latest_version'] . '.'
                    : 'Sprawdzono repozytorium GitHub. Nie ma obecnie opublikowanej nowszej paczki.';
            } elseif ($action === 'download_central_update') {
                $downloaded = i24UpdateDownloadCentralPackage($env, $private, $root);
                go('/admin/updates?package=' . rawurlencode($downloaded['id']) . '&downloaded=' . rawurlencode($downloaded['version']));
            } elseif ($action === 'upload') {
                if (!isset($_FILES['package']) || $_FILES['package']['error'] !== UPLOAD_ERR_OK) throw new RuntimeException('Nie udało się przesłać pliku ZIP.');
                if ((int)$_FILES['package']['size'] > 25 * 1024 * 1024) throw new RuntimeException('Maksymalny rozmiar paczki to 25 MB.');
                $tmp = (string)$_FILES['package']['tmp_name'];
                if (!is_uploaded_file($tmp)) throw new RuntimeException('Nieprawidłowy plik przesłany do instalatora.');
                $validated = i24UpdateValidateZip($tmp, $env, true);
                $id = date('YmdHis') . '-' . bin2hex(random_bytes(4));
                $dest = $root . '/package-' . $id . '.zip';
                if (!move_uploaded_file($tmp, $dest)) throw new RuntimeException('Nie można zapisać paczki na serwerze.');
                @chmod($dest, 0600);
                file_put_contents($root . '/package-' . $id . '.json', json_encode([
                    'id'=>$id, 'version'=>$validated['manifest']['version'], 'target_environment'=>$env,
                    'uploaded_at'=>date(DATE_ATOM), 'file_count'=>$validated['count'], 'size'=>$validated['size'],
                    'sha256'=>hash_file('sha256', $dest), 'status'=>'validated',
                    'release_name'=>is_string($validated['manifest']['name'] ?? null) ? substr(trim($validated['manifest']['name']), 0, 120) : '',
                    'release_notes'=>i24UpdateReleaseNotes($validated['manifest']['release_notes'] ?? null)
                ], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES), LOCK_EX);
                i24UpdateJournal($root, ['event'=>'package_validated','version'=>$validated['manifest']['version'],'package_id'=>$id,'files'=>$validated['count']]);
                go('/admin/updates?package=' . rawurlencode($id));
            } elseif (in_array($action, ['install', 'install_central_update'], true)) {
                if ($action === 'install_central_update') {
                    // One-click path: download, verify, then reuse the normal guarded installer.
                    $downloaded = i24UpdateDownloadCentralPackage($env, $private, $root);
                    $_POST['id'] = $downloaded['id'];
                    $_POST['confirm_environment'] = $env;
                }
                $id = preg_replace('/[^0-9A-Za-z-]/', '', (string)($_POST['id'] ?? ''));
                $metaFile = $root . '/package-' . $id . '.json'; $zipFile = $root . '/package-' . $id . '.zip';
                if ($id === '' || !is_file($metaFile) || !is_file($zipFile)) throw new RuntimeException('Nie znaleziono paczki.');
                if (!hash_equals($env, (string)($_POST['confirm_environment'] ?? ''))) throw new RuntimeException('Wpisz dokładną nazwę środowiska: ' . $env);
                $validated = i24UpdateValidateZip($zipFile, $env, true);
                $meta = json_decode((string)file_get_contents($metaFile), true);
                if (!is_array($meta) || (string)($meta['target_environment'] ?? '') !== $env || (string)($meta['version'] ?? '') !== (string)$validated['manifest']['version'] || !hash_equals((string)($meta['sha256'] ?? ''), hash_file('sha256', $zipFile))) throw new RuntimeException('Metadane paczki nie zgadzają się z archiwum lub środowiskiem.');
                $backup = i24BackupCreate($db, 'full');
                $oldVersion = i24UpdateVersion();
                $domain = dirname(__DIR__, 2);
                $rollbackKey = 'rollback-' . $id . '-' . date('YmdHis') . '-' . bin2hex(random_bytes(3));
                $rollbackDir = $root . '/' . $rollbackKey;
                if (!mkdir($rollbackDir, 0700)) throw new RuntimeException('Nie można utworzyć katalogu wycofania.');
                $z = new ZipArchive(); if ($z->open($zipFile) !== true) throw new RuntimeException('Nie można otworzyć paczki.');
                $changed = [];
                try {
                    foreach ($validated['files'] as $entry) {
                        $rel = (string)$entry['path'];
                        $dest = i24UpdateAssertSafeDestination($domain, $rel, $env);
                        $parent = dirname($dest);
                        if (!is_dir($parent) && !mkdir($parent, 0750, true) && !is_dir($parent)) throw new RuntimeException('Nie można utworzyć katalogu: ' . dirname($rel));
                        $dest = i24UpdateAssertSafeDestination($domain, $rel, $env);
                        if (is_file($dest)) {
                            $backupName = hash('sha256', $rel) . '.bak';
                            if (!copy($dest, $rollbackDir . '/' . $backupName)) throw new RuntimeException('Nie udało się zabezpieczyć pliku: ' . $rel);
                            $changed[] = ['path'=>$rel, 'backup'=>$backupName, 'existed'=>true];
                        } else $changed[] = ['path'=>$rel, 'backup'=>'', 'existed'=>false];
                        $data = $z->getFromName('files/' . $rel);
                        if (!is_string($data)) throw new RuntimeException('Nie można odczytać pliku: ' . $rel);
                        $stage = $dest . '.i24new-' . bin2hex(random_bytes(3));
                        if (file_put_contents($stage, $data, LOCK_EX) === false) throw new RuntimeException('Nie można zapisać pliku: ' . $rel);
                        @chmod($stage, 0640);
                        if (!rename($stage, $dest)) { @unlink($stage); throw new RuntimeException('Nie można podmienić pliku: ' . $rel); }
                    }
                } catch (Throwable $applyError) {
                    foreach (array_reverse($changed) as $item) {
                        $dest = i24UpdateAssertSafeDestination($domain, (string)$item['path'], $env);
                        if ($item['existed'] && is_file($rollbackDir . '/' . $item['backup'])) @copy($rollbackDir . '/' . $item['backup'], $dest);
                        elseif (!$item['existed'] && is_file($dest)) @unlink($dest);
                    }
                    throw $applyError;
                } finally { $z->close(); }
                $versionFile = $private . '/VERSION';
                $packageStatusSnapshot = [];
                try {
                    $packageStatusSnapshot = i24UpdateSnapshotPackageStatuses($root, $env);
                    i24UpdateWriteAtomic($versionFile, (string)$validated['manifest']['version'] . "\n", 0640);
                    $rollbackJson = json_encode(['version'=>$validated['manifest']['version'], 'previous_version'=>$oldVersion, 'environment'=>$env, 'backup'=>$backup['name'], 'files'=>$changed], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);
                    i24UpdateWriteAtomic($rollbackDir . '/rollback.json', $rollbackJson, 0600);
                    $meta['status'] = 'installed'; $meta['installed_at'] = date(DATE_ATOM); $meta['backup'] = $backup['name'];
                    $meta['rollback_dir'] = $rollbackKey;
                    $meta['rollback_history'] = is_array($meta['rollback_history'] ?? null) ? $meta['rollback_history'] : [];
                    $meta['rollback_history'][] = ['directory'=>$rollbackKey, 'previous_version'=>$oldVersion, 'created_at'=>date(DATE_ATOM)];
                    $metaJson = json_encode($meta, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);
                    i24UpdateWriteAtomic($metaFile, $metaJson, 0600);
                    i24UpdateSyncPackageStatuses($root, $env, (string)$validated['manifest']['version'], $id);
                } catch (Throwable $finalizeError) {
                    foreach (array_reverse($changed) as $item) {
                        $restoreDest = i24UpdateAssertSafeDestination($domain, (string)$item['path'], $env);
                        if (!empty($item['existed'])) {
                            $source = $rollbackDir . '/' . basename((string)$item['backup']);
                            if (is_file($source)) {
                                $restoreTmp = dirname($restoreDest) . '/.i24restore-' . bin2hex(random_bytes(6));
                                if (!copy($source, $restoreTmp) || !rename($restoreTmp, $restoreDest)) {
                                    @unlink($restoreTmp);
                                    error_log('Informatyk-24 update rollback failed for ' . (string)$item['path']);
                                }
                            }
                        } elseif (is_file($restoreDest)) {
                            @unlink($restoreDest);
                        }
                    }
                    i24UpdateWriteAtomic($versionFile, $oldVersion . "\n", 0640);
                    if ($packageStatusSnapshot) {
                        try { i24UpdateRestorePackageStatuses($root, $packageStatusSnapshot); }
                        catch (Throwable $restoreMetaError) { error_log('Informatyk-24 package metadata restore failed: ' . $restoreMetaError->getMessage()); }
                    }
                    throw $finalizeError;
                }
                i24UpdateJournal($root, ['event'=>'package_installed','version'=>$validated['manifest']['version'],'previous_version'=>$oldVersion,'package_id'=>$id,'backup'=>$backup['name']]);
                go('/admin/updates?installed=' . rawurlencode((string)$validated['manifest']['version']));
            } elseif ($action === 'rollback') {
                $id = preg_replace('/[^0-9A-Za-z-]/', '', (string)($_POST['id'] ?? ''));
                $packageMetaFile = $root . '/package-' . $id . '.json';
                if ($id === '' || !is_file($packageMetaFile)) throw new RuntimeException('Nie znaleziono paczki wdrożenia.');
                if (!hash_equals($env, (string)($_POST['confirm_environment'] ?? ''))) throw new RuntimeException('Wpisz dokładną nazwę środowiska: ' . $env);
                $packageMeta = json_decode((string)file_get_contents($packageMetaFile), true);
                if (!is_array($packageMeta) || (string)($packageMeta['target_environment'] ?? '') !== $env) throw new RuntimeException('Nieprawidłowe metadane paczki.');
                $rollbackDir = i24UpdateRollbackDirectory($root, $packageMeta, $id);
                $rollbackMeta = $rollbackDir . '/rollback.json';
                $rm = json_decode((string)file_get_contents($rollbackMeta), true);
                if (!is_array($rm) || ($rm['environment'] ?? '') !== $env || !is_array($rm['files'] ?? null)) throw new RuntimeException('Nieprawidłowe metadane wycofania.');
                $safetyBackup = i24BackupCreate($db, 'full');
                $domain = dirname(__DIR__, 2);
                foreach (array_reverse($rm['files']) as $item) {
                    $rel = (string)($item['path'] ?? '');
                    if (!i24UpdateAllowedPath($rel, $env)) throw new RuntimeException('Niedozwolona ścieżka w punkcie wycofania.');
                    $dest = i24UpdateAssertSafeDestination($domain, $rel, $env);
                    if (!empty($item['existed'])) {
                        $source = $rollbackDir . '/' . basename((string)($item['backup'] ?? ''));
                        if (!is_file($source) || !copy($source, $dest)) throw new RuntimeException('Nie udało się przywrócić pliku: ' . $rel);
                    } elseif (is_file($dest)) @unlink($dest);
                }
                $previous = (string)($rm['previous_version'] ?? '');
                if (!preg_match('/^\d+\.\d+\.\d+(?:\.\d+)?$/', $previous)) throw new RuntimeException('Brak poprawnego numeru poprzedniej wersji.');
                i24UpdateWriteAtomic($private . '/VERSION', $previous . "\n", 0640);
                $statusSnapshot = i24UpdateSnapshotPackageStatuses($root, $env);
                try {
                    $metaFile = $root . '/package-' . $id . '.json';
                    if (is_file($metaFile)) { $meta = json_decode((string)file_get_contents($metaFile), true) ?: []; $meta['status']='rolled_back'; $meta['rolled_back_at']=date(DATE_ATOM); $meta['rollback_safety_backup']=$safetyBackup['name']; i24UpdateWriteAtomic($metaFile, json_encode($meta, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR), 0600); }
                    i24UpdateSyncPackageStatuses($root, $env, $previous, null, $id);
                } catch (Throwable $statusError) {
                    try { i24UpdateRestorePackageStatuses($root, $statusSnapshot); }
                    catch (Throwable $restoreMetaError) { error_log('Informatyk-24 rollback metadata restore failed: ' . $restoreMetaError->getMessage()); }
                    throw $statusError;
                }
                i24UpdateJournal($root, ['event'=>'package_rolled_back','version'=>$previous,'rolled_back_version'=>$packageMeta['version'] ?? '','package_id'=>$id,'backup'=>$safetyBackup['name']]);
                go('/admin/updates?rolledback=' . rawurlencode($previous));
            } elseif ($action === 'clear_journal_errors') {
                $journalFile = $root . '/deployment-journal.jsonl';
                $journalLock = @fopen($root . '/journal.lock', 'c');
                if (!$journalLock) throw new RuntimeException('Nie można otworzyć blokady dziennika.');
                @chmod($root . '/journal.lock', 0600);
                if (!flock($journalLock, LOCK_EX)) { fclose($journalLock); throw new RuntimeException('Nie można zablokować dziennika.'); }
                try {
                    $allLines = is_file($journalFile) ? (file($journalFile, FILE_IGNORE_NEW_LINES) ?: []) : [];
                    $keptLines = [];
                    $removedErrors = 0;
                    foreach ($allLines as $journalLine) {
                        if (trim($journalLine) === '') continue;
                        $journalEvent = json_decode($journalLine, true);
                        if (is_array($journalEvent) && (string)($journalEvent['event'] ?? '') === 'operation_failed') {
                            $removedErrors++;
                            continue;
                        }
                        $keptLines[] = $journalLine;
                    }
                    $keptLines[] = json_encode([
                        'at'=>date(DATE_ATOM), 'environment'=>$env,
                        'event'=>'journal_errors_cleared', 'removed_errors'=>$removedErrors
                    ], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
                    $journalTmp = $journalFile . '.tmp-' . bin2hex(random_bytes(6));
                    $journalData = implode("\n", $keptLines) . "\n";
                    if (file_put_contents($journalTmp, $journalData, LOCK_EX) === false || !rename($journalTmp, $journalFile)) {
                        @unlink($journalTmp);
                        throw new RuntimeException('Nie udało się bezpiecznie zaktualizować dziennika.');
                    }
                    @chmod($journalFile, 0600);
                } finally {
                    flock($journalLock, LOCK_UN);
                    fclose($journalLock);
                }
                go('/admin/updates?journal_cleaned=' . $removedErrors);
            } elseif ($action === 'delete') {
                $id = preg_replace('/[^0-9A-Za-z-]/', '', (string)($_POST['id'] ?? ''));
                $metaFile = $root . '/package-' . $id . '.json';
                if ($id === '' || !is_file($metaFile)) throw new RuntimeException('Nie znaleziono paczki.');
                $deleteMeta = json_decode((string)file_get_contents($metaFile), true);
                if (!is_array($deleteMeta) || (string)($deleteMeta['target_environment'] ?? '') !== $env) throw new RuntimeException('Nieprawidłowe metadane paczki.');
                if ((string)($deleteMeta['status'] ?? '') === 'installed' || (string)($deleteMeta['version'] ?? '') === i24UpdateVersion()) throw new RuntimeException('Nie można usunąć archiwum aktualnie działającej wersji.');
                foreach (['zip','json'] as $ext) { $f=$root.'/package-'.$id.'.'.$ext; if(is_file($f)) @unlink($f); }
                i24UpdateJournal($root, ['event'=>'package_deleted','version'=>$deleteMeta['version'] ?? '','package_id'=>$id]);
                go('/admin/updates');
            }
        } catch (Throwable $e) { $error = $e->getMessage(); i24UpdateJournal($root, ['event'=>'operation_failed','action'=>$action,'error'=>substr($e->getMessage(),0,500)]); }
    }
    $version = i24UpdateVersion();
    if (isset($_GET['installed'])) $notice = 'Zainstalowano wersję ' . (string)$_GET['installed'] . '.';
    if (isset($_GET['rolledback'])) $notice = 'Wycofano aktualizację. Przywrócono wersję ' . (string)$_GET['rolledback'] . '.';
    if (isset($_GET['downloaded'])) $notice = 'Pobrano i zweryfikowano paczkę wersji ' . (string)$_GET['downloaded'] . '. Możesz ją teraz zainstalować z listy paczek.';
    $selected = preg_replace('/[^0-9A-Za-z-]/', '', (string)($_GET['package'] ?? ''));
    $packageFiles = glob($root . '/package-*.json') ?: [];
    $packageItems = [];
    foreach ($packageFiles as $mf) {
        $m = json_decode((string)file_get_contents($mf), true);
        if (!is_array($m) || (string)($m['target_environment'] ?? '') !== $env) continue;
        $packageItems[] = ['file'=>$mf, 'meta'=>$m];
    }
    usort($packageItems, static function(array $a, array $b) use ($version): int {
        $aActive = (($a['meta']['status'] ?? '') === 'installed' && (string)($a['meta']['version'] ?? '') === $version) ? 1 : 0;
        $bActive = (($b['meta']['status'] ?? '') === 'installed' && (string)($b['meta']['version'] ?? '') === $version) ? 1 : 0;
        if ($aActive !== $bActive) return $bActive <=> $aActive;
        $cmp = version_compare((string)($a['meta']['version'] ?? '0'), (string)($b['meta']['version'] ?? '0'));
        if ($cmp !== 0) return -$cmp;
        return strcmp((string)($b['meta']['uploaded_at'] ?? ''), (string)($a['meta']['uploaded_at'] ?? ''));
    });
    $journalFile = $root . '/deployment-journal.jsonl';
    $journalEvents = [];
    if (is_file($journalFile) && is_readable($journalFile)) {
        $journalLines = file($journalFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [];
        foreach (array_slice($journalLines, -500) as $journalLine) {
            $event = json_decode($journalLine, true);
            if (is_array($event) && (string)($event['environment'] ?? '') === $env) $journalEvents[] = $event;
        }
    }
    if (($_GET['export'] ?? '') === 'journal-json') {
        $filename = 'informatyk24-deployment-report-' . $env . '-' . date('Ymd-His') . '.json';
        header('Content-Type: application/json; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('X-Content-Type-Options: nosniff');
        echo json_encode(['schema'=>'i24-deployment-report-v1','generated_at'=>date(DATE_ATOM),'environment'=>$env,'installed_version'=>$version,'events_count'=>count($journalEvents),'events'=>$journalEvents], JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);
        exit;
    }
    $journalCounts = ['package_installed'=>0,'package_rolled_back'=>0,'operation_failed'=>0,'other'=>0];
    foreach ($journalEvents as $event) { $t=(string)($event['event'] ?? 'unknown'); if(isset($journalCounts[$t])) $journalCounts[$t]++; else $journalCounts['other']++; }
    $journalRows = '';
    foreach (array_reverse($journalEvents) as $event) {
        $t=(string)($event['event'] ?? 'unknown');
        $labels=['package_installed'=>'Instalacja zakończona','package_rolled_back'=>'Wycofanie zakończone','operation_failed'=>'Operacja zakończona błędem','package_deleted'=>'Usunięto archiwum','journal_errors_cleared'=>'Wyczyszczono błędy dziennika'];
        $details=[];
        foreach (['previous_version'=>'Poprzednia wersja','rolled_back_version'=>'Wycofana wersja','package_id'=>'ID paczki','backup'=>'Backup','action'=>'Akcja','error'=>'Szczegóły błędu','removed_errors'=>'Usunięte błędy'] as $k=>$label) if(isset($event[$k]) && (string)$event[$k]!=='') $details[]=$label.': '.(string)$event[$k];
        $journalRows .= '<tr><td>'.e((string)($event['at'] ?? '—')).'</td><td><strong>'.e($labels[$t] ?? $t).'</strong><br><small>'.e($t).'</small></td><td>'.e((string)($event['version'] ?? $event['rolled_back_version'] ?? '—')).'</td><td>'.e(implode(' · ',$details)).'</td></tr>';
    }
    if($journalRows==='') $journalRows='<tr><td colspan="4" class="i24-update-empty">Brak zapisanych operacji dla tego środowiska.</td></tr>';
    if (($_GET['export'] ?? '') === 'csv') {
        $filename = 'informatyk24-update-history-' . $env . '-' . date('Ymd-His') . '.csv';
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('X-Content-Type-Options: nosniff');
        $out = fopen('php://output', 'wb');
        fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out, ['Wersja','Środowisko','Status','ID paczki','Przesłano','Zainstalowano','Wycofano','Liczba plików','Rozmiar KB','SHA-256','Nazwa wydania','Opis wydania','Katalog rollback'], ';');
        $csvSafe = static function($value): string { $value = (string)$value; return preg_match('/^[=+\-@\t\r]/', $value) ? "'" . $value : $value; };
        foreach ($packageItems as $item) {
            $m = $item['meta'];
            $rn = i24UpdateResolveHistoricalNotes($root, $m, (string)($m['id'] ?? ''));
            $summary = (string)($rn['notes']['summary'] ?? '');
            $sections = [];
            foreach (($rn['notes']['sections'] ?? []) as $section) {
                $parts = array_map('strval', (array)($section['items'] ?? []));
                $sections[] = (string)($section['title'] ?? '') . ': ' . implode(' | ', $parts);
            }
            $description = trim($summary . ($sections ? ' | ' . implode(' || ', $sections) : ''));
            fputcsv($out, [
                $csvSafe($m['version'] ?? ''), $csvSafe($m['target_environment'] ?? ''),
                $csvSafe($m['status'] ?? 'unknown'), $csvSafe($m['id'] ?? ''),
                $csvSafe($m['uploaded_at'] ?? ''), $csvSafe($m['installed_at'] ?? ''),
                $csvSafe($m['rolled_back_at'] ?? ''), (int)($m['file_count'] ?? 0),
                number_format(((int)($m['size'] ?? 0))/1024, 1, '.', ''),
                $csvSafe($m['sha256'] ?? ''), $csvSafe($rn['name'] ?? ''), $csvSafe($description),
                $csvSafe($m['rollback_dir'] ?? '')
            ], ';');
        }
        fclose($out);
        exit;
    }
    $activeCount = 0; $historyCount = 0; $rolledBackCount = 0; $readyCount = 0;
    $activePackageId = '';
    foreach ($packageItems as $candidate) { $cm=$candidate['meta']; if ((string)($cm['version'] ?? '') === $version && !in_array((string)($cm['status'] ?? ''), ['rolled_back','validated'], true)) { $activePackageId=(string)($cm['id'] ?? ''); break; } }
    if ($activePackageId === '' && preg_match('/^\d+\.\d+\.\d+(?:\.\d+)?$/', $version)) $activeCount = 1; // bieżąca wersja może być wdrożona ręcznie i nie mieć rekordu ZIP
    $latestInstalled = null; $integrityChecked = 0; $integrityIssues = 0; $missingArchives = 0; $hashMismatches = 0;
    foreach ($packageItems as $item) {
        $m = $item['meta']; $st = (string)($m['status'] ?? 'unknown');
        if ($activePackageId !== '' && (string)($m['id'] ?? '') === $activePackageId) $activeCount++;
        elseif ($st === 'rolled_back') $rolledBackCount++;
        elseif ($st === 'validated') $readyCount++;
        else $historyCount++;
        $installedAt = (string)($m['installed_at'] ?? '');
        if ($installedAt !== '' && ($latestInstalled === null || strcmp($installedAt, (string)($latestInstalled['meta']['installed_at'] ?? '')) > 0)) $latestInstalled = $item;
        $idForCheck = (string)($m['id'] ?? '');
        if ($idForCheck === '') { $integrityIssues++; continue; }
        $archive = $root . '/package-' . $idForCheck . '.zip';
        if (!is_file($archive)) { $missingArchives++; $integrityIssues++; continue; }
        $integrityChecked++;
        $expectedHash = strtolower((string)($m['sha256'] ?? ''));
        $actualHash = hash_file('sha256', $archive);
        if ($expectedHash === '' || !is_string($actualHash) || !hash_equals($expectedHash, strtolower($actualHash))) { $hashMismatches++; $integrityIssues++; }
    }
    $rows = '';
    foreach ($packageItems as $item) {
        $m = $item['meta'];
        $id = (string)($m['id'] ?? '');
        $packageVersion = (string)($m['version'] ?? '');
        $status = (string)($m['status'] ?? 'unknown');
        $isActive = ($activePackageId !== '' && $id === $activePackageId) || ($status === 'installed' && $packageVersion === $version);
        // A manual deployment can advance VERSION without a matching package record.
        // Do not keep an older installed package visually marked as active.
        $displayStatus = ($status === 'installed' && $packageVersion !== $version) ? 'superseded' : $status;
        $statusMap = [
            'installed' => ['Aktywna', 'active'],
            'superseded' => ['Zainstalowana wcześniej', 'history'],
            'rolled_back' => ['Wycofana', 'rolledback'],
            'validated' => ['Gotowa do instalacji', 'ready'],
        ];
        [$statusLabel, $statusClass] = $statusMap[$displayStatus] ?? ['Nieznany status', 'unknown'];
        $zipExists = is_file($root . '/package-' . $id . '.zip');
        $resolvedRelease = i24UpdateResolveHistoricalNotes($root, $m, $id);
        $notes = $resolvedRelease['notes'];
        $releaseName = $resolvedRelease['name'];
        $searchParts = [$packageVersion, $id, $env, $releaseName, (string)($notes['summary'] ?? '')];
        foreach (($notes['sections'] ?? []) as $section) { $searchParts[] = (string)($section['title'] ?? ''); foreach (($section['items'] ?? []) as $noteText) $searchParts[] = (string)$noteText; }
        foreach (($resolvedRelease['files'] ?? []) as $fileText) $searchParts[] = (string)$fileText;
        $searchText = strtolower(implode(' ', $searchParts));
        $dateValue = substr((string)($m['installed_at'] ?? $m['uploaded_at'] ?? ''), 0, 10);
        $rowClass = $isActive ? 'i24-update-active-row' : '';
        $rows .= '<tr class="i24-update-row '.e($rowClass).'" data-status="'.e($statusClass).'" data-date="'.e($dateValue).'" data-search="'.e($searchText).'">';
        $rows .= '<td><strong class="i24-update-version">'.e($packageVersion).'</strong><br><small class="i24-update-id">'.e($id).'</small></td>';
        $rows .= '<td>'.e((string)($m['target_environment'] ?? '')).'</td>';
        $rows .= '<td>'.e((string)($m['file_count'] ?? 0)).' plików</td>';
        $rows .= '<td><span class="i24-update-badge i24-update-badge-'.e($statusClass).'">'.e($statusLabel).'</span></td><td class="i24-update-actions">';
        if (!$isActive && $zipExists) {
            $rows .= '<form method="post" class="i24-update-action-form">'.csrfField().'<input type="hidden" name="action" value="install"><input type="hidden" name="id" value="'.e($id).'">';
            $rows .= '<input name="confirm_environment" placeholder="Wpisz '.e($env).'" required aria-label="Potwierdź środowisko '.e($env).'">';
            $rows .= '<button class="btn i24-update-btn" type="submit" onclick="return confirm(\'Wykonać pełny backup i zainstalować wersję '.e($packageVersion).' ?\')">Zainstaluj</button></form> ';
        }
        $hasRollback = is_file($root . '/rollback-' . $id . '/rollback.json') || (preg_match('/^rollback-[0-9A-Za-z-]+$/', (string)($m['rollback_dir'] ?? '')) && is_file($root . '/' . (string)$m['rollback_dir'] . '/rollback.json'));
        if ($isActive && $hasRollback) {
            $rows .= '<form method="post" class="i24-update-action-form">'.csrfField().'<input type="hidden" name="action" value="rollback"><input type="hidden" name="id" value="'.e($id).'">';
            $rows .= '<input name="confirm_environment" placeholder="Wpisz '.e($env).'" required aria-label="Potwierdź środowisko '.e($env).'">';
            $rows .= '<button class="btn i24-update-btn i24-update-btn-secondary" type="submit" onclick="return confirm(\'Wycofać aktualizację? Najpierw zostanie wykonany pełny backup.\')">Wycofaj</button></form> ';
        }
        if (!$isActive && $packageVersion !== $version) {
            $rows .= '<form method="post" class="i24-update-delete-form">'.csrfField().'<input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="'.e($id).'">';
            $rows .= '<button class="btn i24-update-btn i24-update-btn-delete" type="submit" onclick="return confirm(\'Usunąć archiwum paczki '.e($packageVersion). '? Tej operacji nie można cofnąć.\')">Usuń</button></form>';
        }
        $rows .= '</td></tr>';
        $rows .= '<tr class="i24-update-release-row"><td colspan="5"><details class="i24-update-release"><summary>Co wprowadza wersja '.e($packageVersion).'?</summary><div class="i24-update-release-body">';
        if ($releaseName !== '') $rows .= '<strong class="i24-update-release-name">'.e($releaseName).'</strong>';
        if ($notes['summary'] !== '') $rows .= '<p class="i24-update-release-summary">'.nl2br(e($notes['summary'])).'</p>';
        if ($notes['sections']) {
            foreach ($notes['sections'] as $section) {
                $rows .= '<h4>'.e($section['title']).'</h4><ul>';
                foreach ($section['items'] as $noteItem) $rows .= '<li>'.e($noteItem).'</li>';
                $rows .= '</ul>';
            }
        } elseif ($resolvedRelease['files']) {
            $rows .= '<h4>Pliki znajdujące się w archiwum</h4><ul>';
            foreach ($resolvedRelease['files'] as $fileEntry) $rows .= '<li><code>'.e($fileEntry).'</code></li>';
            $rows .= '</ul><p class="i24-update-release-missing">Archiwum nie zawierało opisu funkcjonalnego. Powyżej pokazano wyłącznie potwierdzoną zawartość.</p>';
        } else {
            $rows .= '<p class="i24-update-release-missing">W zachowanym archiwum nie znaleziono opisu wydania ani instrukcji README. Nie dopisano niepotwierdzonych zmian.</p>';
        }
        $rows .= '<p class="i24-update-release-source">Źródło: '.e($resolvedRelease['source']).'</p>';
        $rows .= '</div></details></td></tr>';
        if ($selected === $id) {
            $rows .= '<tr><td colspan="5" class="i24-update-details"><strong>Szczegóły paczki</strong><br>SHA-256: <code>'.e((string)($m['sha256'] ?? '')).'</code><br>Przesłano: '.e((string)($m['uploaded_at'] ?? '')).'<br>Instalowano: '.e((string)($m['installed_at'] ?? '—')).'<br>Rozmiar: '.e(number_format(((int)($m['size'] ?? 0))/1024, 1, ',', ' ')).' KB</td></tr>';
        }
    }
    // Runtime diagnostics are rendered by this active dashboard file (not the app handler).
    $preflightRows = '';
    foreach (i24UpdatePreflight($private, $root) as $check) {
        $preflightRows .= '<tr><td>'.e($check['name']).'</td><td>'.($check['ok']?'<span class="i24-update-badge i24-update-badge-active">OK</span>':'<span class="i24-update-badge i24-update-badge-rolledback">UWAGA</span>').'</td><td>'.e($check['detail']).'</td></tr>';
    }
    $healthRows = '';
    {
        foreach (i24UpdateHealthProbe($db, $private) as $check) {
            $healthRows .= '<tr><td>'.e($check['name']).'</td><td>'.($check['ok']?'<span class="i24-update-badge i24-update-badge-active">OK</span>':'<span class="i24-update-badge i24-update-badge-rolledback">BŁĄD</span>').'</td><td>'.e($check['detail']).'</td></tr>';
        }
    }
    $journalLines = is_file($root . '/deployment-journal.jsonl') ? (file($root . '/deployment-journal.jsonl', FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES) ?: []) : [];
    $journalLines = array_slice($journalLines, -30);
    $journalRows = '';
    foreach (array_reverse($journalLines) as $line) {
        $event = json_decode($line, true);
        if (!is_array($event)) continue;
        $eventLabels = ['package_validated'=>'Sprawdzono paczkę','package_installed'=>'Zainstalowano paczkę','package_rolled_back'=>'Wycofano aktualizację','package_deleted'=>'Usunięto archiwum','operation_failed'=>'Błąd operacji'];
        $eventName = (string)($event['event'] ?? 'unknown');
        $journalDetail = '';
        if ($eventName === 'operation_failed') {
            $journalDetail = trim((string)($event['action'] ?? '') . ' — ' . (string)($event['error'] ?? ''));
        } elseif ($eventName === 'journal_errors_cleared') {
            $journalDetail = 'Usunięte wpisy błędów: ' . (int)($event['removed_errors'] ?? 0);
        } elseif (isset($event['previous_version'])) {
            $journalDetail = 'Poprzednia wersja: ' . (string)$event['previous_version'];
        }
        $journalLabel = $eventLabels[$eventName] ?? ($eventName === 'journal_errors_cleared' ? 'Oczyszczono błędy dziennika' : $eventName);
        $journalRows .= '<tr><td>'.e((string)($event['at'] ?? '')).'</td><td>'.e($journalLabel).'</td><td>'.e((string)($event['version'] ?? '')).'</td><td>'.e((string)($event['package_id'] ?? '')).'</td><td>'.e($journalDetail).'</td></tr>';
    }
    $diagnosticsHtml = '<div class="i24-update-dashboard"><div class="i24-update-panel"><h2>Kontrola wstępna środowiska</h2><div style="overflow:auto"><table class="i24-update-table"><thead><tr><th>Kontrola</th><th>Status</th><th>Szczegóły</th></tr></thead><tbody>'.$preflightRows.'</tbody></table></div></div>'
      .'<div class="i24-update-panel"><h2>Dziennik wdrożeń</h2><p class="i24-update-integrity-meta">Czyszczenie usuwa wyłącznie wpisy błędów operacji; historia udanych wdrożeń pozostaje bez zmian.</p><form method="post" style="margin:0 0 10px" onsubmit="return confirm(\'Usunąć z dziennika wyłącznie wpisy błędów operacji? Historia udanych wdrożeń pozostanie bez zmian.\')">'.csrfField().'<input type="hidden" name="action" value="clear_journal_errors"><button class="btn i24-update-btn i24-update-btn-secondary" type="submit">Wyczyść wpisy błędów</button></form><div style="overflow:auto"><table class="i24-update-table"><thead><tr><th>Data</th><th>Zdarzenie</th><th>Wersja</th><th>Pakiet</th><th>Informacje</th></tr></thead><tbody>'.($journalRows !== '' ? $journalRows : '<tr><td colspan="5">Brak zapisanych zdarzeń.</td></tr>').'</tbody></table></div></div></div>'
      .($healthRows !== '' ? '<div class="i24-update-panel"><h2>Automatyczna diagnostyka</h2><div style="overflow:auto"><table class="i24-update-table"><thead><tr><th>Kontrola</th><th>Status</th><th>Szczegóły</th></tr></thead><tbody>'.$healthRows.'</tbody></table></div></div>' : '');
    $centralUpdateHtml = '<div class="i24-update-panel" style="margin:16px 0"><h2>Centralne repozytorium aktualizacji</h2>'
      . '<p class="i24-update-integrity-meta">Źródło: GitHub · kanał stabilny · środowisko ' . e($env) . '. Pobranie weryfikuje SHA-256, rozmiar, wersję i zawartość ZIP; instalacja wymaga osobnego potwierdzenia.</p>'
      . '<form method="post" style="margin:10px 0">' . csrfField() . '<input type="hidden" name="action" value="check_central_updates"><button class="btn" type="submit">Sprawdź aktualizacje</button></form>';
    if (is_array($centralCheck)) {
        $centralUpdateHtml .= '<div class="i24-update-kv"><span>Zainstalowana wersja</span><strong>' . e($centralCheck['installed_version']) . '</strong></div>'
          . '<div class="i24-update-kv"><span>Najnowsza wersja w repozytorium</span><strong>' . e($centralCheck['latest_version']) . '</strong></div>';
        if ($centralCheck['update_available']) {
            $centralUpdateHtml .= '<p><span class="i24-update-badge i24-update-badge-ready">Aktualizacja dostępna</span></p>';
        } elseif (version_compare($centralCheck['latest_version'], $centralCheck['installed_version'], '>')) {
            $centralUpdateHtml .= '<p class="i24-update-integrity-meta">Wersja jest opisana w repozytorium, ale paczka nie została jeszcze opublikowana.</p>';
        } else {
            $centralUpdateHtml .= '<p><span class="i24-update-badge i24-update-badge-active">Masz najnowszą wersję</span></p>';
        }
        if ($centralCheck['update_available'] && $centralCheck['release_available'] && $centralCheck['package_url'] !== '' && $centralCheck['package_sha256'] !== '' && (int)$centralCheck['package_size_bytes'] > 0) {
            $centralUpdateHtml .= '<form method="post" id="i24CentralInstallForm" style="margin:10px 0" onsubmit="if(!confirm(\'Pobrać, zweryfikować i od razu zainstalować wersję ' . e($centralCheck['latest_version']) . '? Najpierw zostanie wykonany pełny backup.\'))return false;var b=this.querySelector(\'button[type=submit]\');if(b){b.disabled=true;b.textContent=\'Instalowanie…\';}var p=document.getElementById(\'i24CentralProgress\');if(p)p.hidden=false;return true;">' . csrfField() . '<input type="hidden" name="action" value="install_central_update"><button class="btn" type="submit">Pobierz i zainstaluj ' . e($centralCheck['latest_version']) . '</button></form>'
              . '<div id="i24CentralProgress" class="i24-central-progress" hidden><strong>Trwa aktualizacja — nie zamykaj tej strony</strong><progress></progress><p>Pobieranie paczki, kontrola SHA-256, wykonywanie kopii bezpieczeństwa i instalowanie plików.</p></div>';
            $centralUpdateHtml .= '<p class="i24-update-integrity-meta">Rozmiar deklarowany: ' . (int)$centralCheck['package_size_bytes'] . ' B · SHA-256 zostanie sprawdzony przed instalacją. Pełny backup wykonywany jest automatycznie.</p>';
        }
        if ($centralCheck['notes']) {
            $centralUpdateHtml .= '<h3>Lista zmian</h3><ul>';
            foreach ($centralCheck['notes'] as $centralNote) $centralUpdateHtml .= '<li>' . e($centralNote) . '</li>';
            $centralUpdateHtml .= '</ul>';
        }
        $centralUpdateHtml .= '<p class="i24-update-integrity-meta">Ostatnie sprawdzenie: ' . e($centralCheck['checked_at']) . '</p>';
    }
    $centralUpdateHtml .= '</div>';
    $content = '<style>
.i24-update-summary{display:grid;grid-template-columns:repeat(4,minmax(110px,1fr));gap:10px;margin:18px 0 22px}
.i24-update-stat{background:#f5f8fc;border:1px solid #e5ebf3;border-radius:12px;padding:13px 15px;min-width:0}
.i24-update-stat strong{display:block;font-size:23px;line-height:1.2;color:#14243b}.i24-update-stat span{display:block;margin-top:4px;font-size:12px;color:#63748b}
.i24-update-dashboard{display:grid;grid-template-columns:minmax(0,1.35fr) minmax(240px,.85fr);gap:12px;margin:18px 0 22px}.i24-update-panel{border:1px solid #e5ebf3;border-radius:13px;background:#fff;padding:16px;min-width:0}.i24-update-panel h2{font-size:15px;margin:0 0 12px;color:#1b2e46}.i24-update-kv{display:flex;justify-content:space-between;gap:12px;padding:8px 0;border-bottom:1px solid #eef2f6;font-size:12px}.i24-update-kv:last-child{border-bottom:0}.i24-update-kv span{color:#718096}.i24-update-kv strong{text-align:right;color:#263b56;overflow-wrap:anywhere}.i24-update-integrity{display:flex;align-items:center;gap:9px;margin-bottom:10px;font-weight:700;font-size:13px}.i24-update-integrity-dot{width:10px;height:10px;border-radius:50%;background:#15945f;flex:0 0 10px}.i24-update-integrity.is-warning .i24-update-integrity-dot{background:#d97706}.i24-update-integrity-meta{font-size:11px;color:#718096;line-height:1.6}.i24-update-dashboard-links{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}.i24-update-dashboard-links a{font-size:11px;font-weight:700;text-decoration:none;color:#315b83;background:#eef4fb;padding:8px 10px;border-radius:8px}
.i24-central-progress{margin:12px 0;padding:14px;border:1px solid #cfe5db;border-radius:10px;background:#f2fbf7;color:#176b49}.i24-central-progress progress{display:block;width:100%;height:12px;margin:10px 0}.i24-central-progress p{margin:0;font-size:12px;color:#526b60}.i24-update-toolbar{display:flex;gap:9px;align-items:center;flex-wrap:wrap;margin:12px 0 14px}.i24-update-search{flex:1 1 220px;max-width:360px;padding:10px 12px;border:1px solid #d8e1eb;border-radius:9px}
.i24-update-date-label{display:inline-flex;align-items:center;gap:5px;font-size:11px;color:#63748b}.i24-update-date-label input{padding:8px;border:1px solid #d8e1eb;border-radius:8px;color:#263b56}.i24-update-export{display:inline-flex;align-items:center;padding:9px 12px;border-radius:9px;background:#e8f5ef;color:#176b49;text-decoration:none;font-size:12px;font-weight:700}.i24-update-filter{border:1px solid #d8e1eb;background:#fff;border-radius:9px;padding:9px 12px;cursor:pointer}.i24-update-filter.is-active{background:#14243b;color:#fff;border-color:#14243b}
.i24-update-table{width:100%;border-collapse:separate;border-spacing:0;min-width:760px}.i24-update-table th{background:#f6f8fb;color:#526278;font-size:12px;text-align:left;padding:12px 10px}.i24-update-table td{padding:11px 10px;border-bottom:1px solid #edf1f5;vertical-align:middle;font-size:13px}.i24-update-active-row{background:#f2fbf7}.i24-update-version{font-size:14px;color:#14243b}.i24-update-id{color:#8290a2;font-size:10px;overflow-wrap:anywhere}.i24-update-badge{display:inline-flex;align-items:center;border-radius:20px;padding:6px 9px;font-size:11px;font-weight:700;white-space:nowrap}.i24-update-badge-active{background:#dcf7e9;color:#137447}.i24-update-badge-history{background:#eaf1ff;color:#315b9b}.i24-update-badge-rolledback{background:#fff0df;color:#9b5a12}.i24-update-badge-ready{background:#e7f7fb;color:#167187}.i24-update-badge-unknown{background:#eef1f4;color:#596579}.i24-update-actions{display:flex;align-items:center;gap:6px;flex-wrap:wrap}.i24-update-action-form{display:inline-flex;align-items:center;gap:5px;flex-wrap:wrap}.i24-update-action-form input{width:118px;min-width:100px;padding:8px;border:1px solid #d7e0e9;border-radius:7px;font-size:11px}.i24-update-btn{padding:8px 12px!important;border-radius:9px!important;white-space:nowrap}.i24-update-btn-secondary{background:#e9eef5!important;color:#263b56!important}.i24-update-btn-delete{background:#f3f5f7!important;color:#667085!important}.i24-update-details{background:#f8fafc;color:#526278;font-size:12px}.i24-update-empty{padding:24px!important;text-align:center;color:#718096}.i24-update-release-row td{padding:0 10px 9px!important;background:#fff}.i24-update-release{border:1px solid #e7edf4;border-radius:10px;background:#fbfcfe;overflow:hidden}.i24-update-release summary{cursor:pointer;list-style:none;padding:10px 13px;font-size:12px;font-weight:700;color:#315b83;display:flex;align-items:center;justify-content:space-between}.i24-update-release summary::-webkit-details-marker{display:none}.i24-update-release summary:after{content:"+";font-size:18px;color:#64748b}.i24-update-release[open] summary:after{content:"−"}.i24-update-release-body{padding:0 14px 13px;color:#526278;font-size:12px;line-height:1.55}.i24-update-release-name{display:block;color:#1b2e46;margin:2px 0 6px}.i24-update-release-summary{margin:4px 0 9px}.i24-update-release-body h4{font-size:12px;color:#263b56;margin:10px 0 4px}.i24-update-release-body ul{margin:4px 0 8px;padding-left:19px}.i24-update-release-body li{margin:3px 0}.i24-update-release-missing{color:#7b8796;font-style:italic;margin:5px 0 0}.i24-update-release-source{font-size:10px;color:#9aa5b3;margin:9px 0 0}
@media(max-width:760px){.i24-update-summary{grid-template-columns:repeat(2,minmax(0,1fr))}.i24-update-dashboard{grid-template-columns:1fr}.i24-update-toolbar{align-items:stretch}.i24-update-search{max-width:none;flex-basis:100%}}
</style>'
      .'<section class="card"><h1>Aktualizacje CMS</h1><p>Środowisko: <strong>'.e($env).'</strong> · Aktualna wersja: <strong>'.e($version).'</strong></p><p class="muted">Paczki są przypisane do konkretnego środowiska. Archiwa historyczne pozostają dostępne do ponownej instalacji. Przed instalacją wykonywana jest pełna kopia bazy i plików. Instalator nie uruchamia automatycznie migracji SQL.</p>'
      .($notice!==''?'<div class="flash">'.e($notice).'</div>':'').($error!==''?'<div class="flash">'.e($error).'</div>':'')
      .$centralUpdateHtml
      .'<div class="i24-update-summary"><div class="i24-update-stat"><strong>'.(int)$activeCount.'</strong><span>Aktywne wdrożenia</span></div><div class="i24-update-stat"><strong>'.(int)$readyCount.'</strong><span>Gotowe do instalacji</span></div><div class="i24-update-stat"><strong>'.(int)$historyCount.'</strong><span>Wersje historyczne</span></div><div class="i24-update-stat"><strong>'.(int)$rolledBackCount.'</strong><span>Wycofane paczki</span></div></div>'
      .'<div class="i24-update-dashboard"><div class="i24-update-panel"><h2>Ostatnie wdrożenie</h2>'
      .'<div class="i24-update-kv"><span>Aktualna wersja</span><strong>'.e($version).'</strong></div>'
      .'<div class="i24-update-kv"><span>Ostatnio zainstalowano</span><strong>'.(($latestInstalled && (string)($latestInstalled['meta']['version'] ?? '') === $version) ? e($version) : e($version).' (wdrożenie ręczne / brak rekordu paczki)').'</strong></div>'
      .'<div class="i24-update-kv"><span>Data instalacji</span><strong>'.(($latestInstalled && (string)($latestInstalled['meta']['version'] ?? '') === $version) ? e((string)($latestInstalled['meta']['installed_at'] ?? '—')) : 'Brak danych z instalatora').'</strong></div>'
      .'<div class="i24-update-kv"><span>Środowisko</span><strong>'.e($env).'</strong></div>'
      .'<div class="i24-update-dashboard-links"><a href="#i24UpdateRows">Historia aktualizacji</a><a href="/admin/updates?export=csv">Pobierz raport CSV</a></div></div>'
      .'<div class="i24-update-panel"><h2>Integralność archiwów</h2>'
      .'<div class="i24-update-integrity'.($integrityIssues > 0 ? ' is-warning' : '').'"><span class="i24-update-integrity-dot"></span><span>'.($integrityIssues > 0 ? 'Wymaga uwagi' : 'Kontrola bez błędów').'</span></div>'
      .'<div class="i24-update-integrity-meta">Sprawdzone archiwa: '.(int)$integrityChecked.'<br>Brakujące archiwa: '.(int)$missingArchives.'<br>Niezgodne sumy SHA-256: '.(int)$hashMismatches.'<br>Łącznie paczek: '.count($packageItems).'</div>'
      .'<p class="i24-update-integrity-meta" style="margin-top:10px">Kontrola obejmuje dostępność pliku ZIP i zgodność jego sumy SHA-256 z zapisanymi metadanymi.</p></div></div>'
      .$diagnosticsHtml
      .'<h2>Wgraj paczkę aktualizacji</h2><form method="post" enctype="multipart/form-data">'.csrfField().'<input type="hidden" name="action" value="upload"><input type="file" name="package" accept=".zip,application/zip" required><button class="btn" type="submit">Sprawdź paczkę</button></form>'
      .'<div class="i24-update-panel" style="margin-top:18px"><div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap"><h2 style="margin:0">Raport operacji i dziennik wdrożeń</h2><a class="i24-update-export" href="/admin/updates?export=journal-json">Pobierz raport JSON</a></div>'
      .'<p class="i24-update-integrity-meta">Ostatnie '.count($journalEvents).' zdarzeń z dziennika środowiska '.e($env).'. Raport jest tylko do odczytu; wpisy nie są usuwane podczas eksportu.</p>'
      .'<div class="i24-update-summary"><div class="i24-update-stat"><strong>'.(int)$journalCounts['package_installed'].'</strong><span>Udane instalacje</span></div><div class="i24-update-stat"><strong>'.(int)$journalCounts['package_rolled_back'].'</strong><span>Wycofania</span></div><div class="i24-update-stat"><strong>'.(int)$journalCounts['operation_failed'].'</strong><span>Błędy operacji</span></div><div class="i24-update-stat"><strong>'.(int)$journalCounts['other'].'</strong><span>Pozostałe zdarzenia</span></div></div>'
      .'<div style="overflow:auto"><table class="i24-update-table" style="min-width:680px"><thead><tr><th>Data</th><th>Zdarzenie</th><th>Wersja</th><th>Szczegóły</th></tr></thead><tbody>'. $journalRows .'</tbody></table></div></div>'
      .'<h2 style="margin-top:24px">Paczki i historia aktualizacji</h2><div class="i24-update-toolbar"><input class="i24-update-search" id="i24UpdateSearch" type="search" placeholder="Szukaj wersji, funkcji, pliku lub ID…" aria-label="Szukaj paczek"><label class="i24-update-date-label">Od <input id="i24UpdateDateFrom" type="date"></label><label class="i24-update-date-label">Do <input id="i24UpdateDateTo" type="date"></label><a class="i24-update-export" href="/admin/updates?export=csv">Eksport CSV</a><button type="button" class="i24-update-filter is-active" data-filter="all">Wszystkie</button><button type="button" class="i24-update-filter" data-filter="active">Aktywna</button><button type="button" class="i24-update-filter" data-filter="history">Historia</button><button type="button" class="i24-update-filter" data-filter="rolledback">Wycofane</button><button type="button" class="i24-update-filter" data-filter="ready">Gotowe</button></div>'
      .'<div style="overflow:auto"><table class="i24-update-table"><thead><tr><th>Wersja</th><th>Środowisko</th><th>Zawartość</th><th>Status</th><th>Operacje</th></tr></thead><tbody id="i24UpdateRows">'.($rows!==''?$rows:'<tr><td colspan="5" class="i24-update-empty">Brak paczek aktualizacji.</td></tr>').'</tbody></table></div><p id="i24UpdateNoResults" class="muted" style="display:none;padding:12px">Brak paczek pasujących do filtra.</p></section>'
      .'<script>(function(){var search=document.getElementById("i24UpdateSearch"),from=document.getElementById("i24UpdateDateFrom"),to=document.getElementById("i24UpdateDateTo"),buttons=document.querySelectorAll(".i24-update-filter"),rows=document.querySelectorAll(".i24-update-row"),empty=document.getElementById("i24UpdateNoResults"),filter="all";function apply(){var q=(search.value||"").toLowerCase(),start=from.value||"",end=to.value||"",shown=0;rows.forEach(function(row){var status=row.getAttribute("data-status"),date=row.getAttribute("data-date")||"",matchFilter=filter==="all"||(filter==="active"&&status==="active")||(filter==="history"&&status==="history")||(filter==="rolledback"&&status==="rolledback")||(filter==="ready"&&status==="ready"),matchSearch=(row.getAttribute("data-search")||"").indexOf(q)!==-1,matchDate=(!start||date>=start)&&(!end||date<=end),show=matchFilter&&matchSearch&&matchDate;row.style.display=show?"":"none";var details=row.nextElementSibling;if(details&&details.classList.contains("i24-update-release-row"))details.style.display=show?"":"none";if(show)shown++;});empty.style.display=shown?"none":"block";}search.addEventListener("input",apply);from.addEventListener("change",apply);to.addEventListener("change",apply);buttons.forEach(function(btn){btn.addEventListener("click",function(){filter=btn.getAttribute("data-filter");buttons.forEach(function(b){b.classList.toggle("is-active",b===btn);});apply();});});})();</script>';
    render('Aktualizacje', $content);
}
