/* Informatyk-24 CMS 1.2.0 — zachowanie responsywnego zaplecza */
(function(){
  'use strict';
  const roots = [document.getElementById('adminShell'), document.getElementById('clientShell')].filter(Boolean);
  if (!roots.length) return;

  roots.forEach(function(root){
    const isAdmin = root.id === 'adminShell';
    const sidebar = root.querySelector(isAdmin ? '.admin-sidebar' : '.client-sidebar');
    const toggle = root.querySelector(isAdmin ? '.admin-mobile-toggle' : '.client-toggle');
    const closeMenu = function(){
      root.classList.remove('mobile-open');
      if (toggle) toggle.setAttribute('aria-expanded', 'false');
    };
    if (toggle) {
      toggle.setAttribute('aria-expanded', root.classList.contains('mobile-open') ? 'true' : 'false');
      toggle.addEventListener('click', function(){
        window.requestAnimationFrame(function(){
          toggle.setAttribute('aria-expanded', root.classList.contains('mobile-open') ? 'true' : 'false');
        });
      });
    }
    if (sidebar) {
      sidebar.addEventListener('click', function(event){
        const link = event.target.closest('a[href]');
        if (link && window.matchMedia('(max-width: 850px)').matches) closeMenu();
      });
    }
    document.addEventListener('click', function(event){
      if (!root.classList.contains('mobile-open')) return;
      if (event.target === root || (!root.contains(event.target) && event.target !== toggle)) closeMenu();
    });
    document.addEventListener('keydown', function(event){
      if (event.key === 'Escape' && root.classList.contains('mobile-open')) {
        closeMenu();
        if (toggle) toggle.focus();
      }
    });
  });

  /* Na telefonach tabele zaplecza zmieniają się w czytelne karty danych. */
  document.querySelectorAll('.admin-main table.table, .client-main table.table').forEach(function(table){
    const rows = Array.from(table.querySelectorAll('tr'));
    if (!rows.length) return;
    const headerRow = rows.find(function(row){ return row.querySelector('th'); });
    if (!headerRow) return;
    headerRow.classList.add('i24-table-header');
    const labels = Array.from(headerRow.querySelectorAll('th')).map(function(cell){ return (cell.textContent || '').trim().replace(/\s+/g, ' '); });
    if (labels.filter(Boolean).length < 2) return;
    rows.forEach(function(row){
      if (row === headerRow) return;
      Array.from(row.querySelectorAll('td')).forEach(function(cell, index){
        if (!cell.hasAttribute('colspan') && labels[index]) cell.setAttribute('data-label', labels[index]);
      });
    });
    table.classList.add('i24-responsive-table');
  });

})();
